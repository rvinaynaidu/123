# Participant Outcomes AWS Stacks

### Goal:
List out all required resources for PO services.

### Resources

| Service       | Name                                   | Region      |
|-----------------|--------------------------------------|-------------|
|Postgres Aurora  | aa00002950-po-dev1-clus-instance-cdk | US-WEST-1   |


|Service        | Path            | Region      |
|---------------|-----------------|-------------|
|Parameter Key  |                 |             |
