package com.capgroup.po.iac;

import com.capgroup.po.iac.exception.PoIACDBException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.json.simple.JSONObject;
import org.junit.Test;

import static com.capgroup.po.iac.util.Messages.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import software.amazon.awscdk.core.App;

import java.io.IOException;

public class PostgresResourceTest {

  private final static ObjectMapper JSON =
      new ObjectMapper().configure(SerializationFeature.INDENT_OUTPUT, true);

  @Test
  public void testNullScope() throws IOException {
    assertThrows(
            IllegalArgumentException.class,
            () -> new PostgresResource(null, null),
            MISSING_REQUIRED_CONSTRUCT
    );
  }

  @Test
  public void testNullCDKJSon() throws IOException {
    final App app = new App();
    assertThrows(
            IllegalArgumentException.class,
            () -> new PostgresResource(app, null),
            MISSING_CDK_JSON_DATA
    );
  }

  @Test
  public void testNullPostgresVersion() throws IOException {
    final App app = new App();
    final JSONObject cdkJson = new JSONObject();
    assertThrows(
            PoIACDBException.class,
            () -> new PostgresResource(app, cdkJson),
            MISSING_DB_VERSION
    );
  }
}
