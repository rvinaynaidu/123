package com.capgroup.po.iac;

import org.json.simple.JSONObject;
import org.junit.Test;
import software.amazon.awscdk.core.App;

import static com.capgroup.po.iac.util.Messages.*;
import static org.junit.jupiter.api.Assertions.*;

public class CodePipelineResourceTest {

  @Test
  public void testNullScope() {
    assertThrows(
            IllegalArgumentException.class,
            () -> new CodePipelineResource(null, null),
            MISSING_REQUIRED_CONSTRUCT
    );
  }

  @Test
  public void testNullEnableCodePipelineCreation() {
    final App app = new App();
    final JSONObject cdkJson = new JSONObject();
    assertThrows(
            UnsupportedOperationException.class,
            () -> new CodePipelineResource(app, cdkJson),
            UNSUPPORTED_ENVIRONMENT_FOR_CODEPIPELINE
    );
  }

  @Test
  public void testEnableCodePipelineCreation() {
    final JSONObject cdkJson = new JSONObject();
    cdkJson.put("create_codepipeline", "true");

    assertDoesNotThrow(
              () -> CodePipelineResource.verifyCodePipelineCreationIsEnabled(cdkJson),
              UNSUPPORTED_ENVIRONMENT_FOR_CODEPIPELINE
    );
  }
}
