package com.capgroup.po.iac;

import com.capgroup.po.iac.domain.EcsFargateService;
import com.capgroup.po.iac.domain.SourceRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.simple.JSONObject;
import software.amazon.awscdk.core.Construct;
import software.amazon.awscdk.core.SecretValue;
import software.amazon.awscdk.services.codebuild.*;
import software.amazon.awscdk.services.codepipeline.*;
import software.amazon.awscdk.services.codepipeline.actions.*;
import software.amazon.awscdk.services.ec2.ISecurityGroup;
import software.amazon.awscdk.services.ec2.IVpc;
import software.amazon.awscdk.services.ecr.IRepository;
import software.amazon.awscdk.services.ecr.Repository;
import software.amazon.awscdk.services.ecs.FargateService;
import software.amazon.awscdk.services.ecs.FargateServiceAttributes;
import software.amazon.awscdk.services.ecs.IBaseService;
import software.amazon.awscdk.services.iam.*;
import software.amazon.awscdk.services.s3.Bucket;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.capgroup.po.iac.util.CDKUtil.*;
import static com.capgroup.po.iac.util.Constants.*;
import static com.capgroup.po.iac.util.Messages.MISSING_REQUIRED_CONSTRUCT;
import static com.capgroup.po.iac.util.Messages.UNSUPPORTED_ENVIRONMENT_FOR_CODEPIPELINE;
import static java.util.Collections.singletonList;

public class CodePipelineResource {

    private static final String ECS_SERVICES = "ecs_services";
    private static final String CREATE_CODEPIPELINE = "create_codepipeline";
    private static final String BUILD_ARTIFACT = "BuildArtifact";
    private static final String SOURCE = "Source";
    private static final String IMPORTED_SERVICE = "ImportedService";
    private static final String BUILD = "Build";
    private static final String DEPLOY = "Deploy";
    private static final String DEPLOY_VARIABLES = "DeployVariables";
    private static final String PO_CODEPIPELINE_BUCKET = "-po-codepipeline-bucket";
    private static final String AWS_ACCOUNT_NUMBER = "aws_account_number";
    private static final String ECR_NAME = "ECR_NAME";
    private static final String DEST_ACCOUNT = "DEST_ACCOUNT";
    private static final String PIPELINE_BRANCH = "PIPELINE_BRANCH";
    private static final String BUILD_SPEC = "buildspec-docker.yml";

    private static final String ECR_SUFFIX = "-ecr";
    private static final String CODEBUILD_SUFFIX = "-cb";
    private static final String CODEPIPELINE_SUFFIX = "-pipeline";
    private static final String PIPELINEPROJECT_SUFFIX = "-pp";
    private static final String CODE_BUILD_PIPELINEPROJECT_SUFFIX = CODEBUILD_SUFFIX + "-pp";
    private static final String CODEBUILD_ROLE_SUFFIX = CODEBUILD_SUFFIX + "-role";
    private static final String ADMIN_BOUNDARY_CODEBUILD = "admin-boundary" + CODEBUILD_SUFFIX;
    private static final String DASH = "-";
    private static final String CODEBUILD_POLICY_SUFFIX = CODEBUILD_SUFFIX + "-policy";

    public CodePipelineResource(final Construct scope, final JSONObject environment) {

    if (scope == null || scope.getNode() == null) {
      throw new IllegalArgumentException(MISSING_REQUIRED_CONSTRUCT);
    }

    verifyCodePipelineCreationIsEnabled(environment);

    final Map<String, String> tags = getConfigurationValue(environment, TAGS);

    final List<String> servicesStr = getConfigurationValue(environment, ECS_SERVICES);

    final IVpc vpc = getVpc(scope, environment);

    final List<ISecurityGroup> securityGroups = getSecurityGroups(scope, environment);

    final ObjectMapper mapper = new ObjectMapper();
    final List<EcsFargateService> services = mapper.convertValue(servicesStr, new TypeReference<>() {});
    final String envName = getConfigurationValue(environment, ENVIRONMENT);

    services.forEach(service -> {

      final IRepository ecrRepository = Repository.fromRepositoryName(scope, createConstructId(service.getId(), ECR_SUFFIX),
              service.getImageName().substring(service.getImageName().lastIndexOf('/')+1));

      final Artifact sourceOutput = new Artifact();
      final Artifact cdkBuildOutput = new Artifact(BUILD_ARTIFACT);
      final SourceRepository sourceRepo = service.getSourceRepo();

      final IAction sourceAction = new GitHubSourceAction(
              GitHubSourceActionProps
                      .builder()
                      .actionName(SOURCE)
                      .repo(sourceRepo.getRepoName())
                      .branch(sourceRepo.getRepoBranch())
                      .oauthToken(SecretValue.secretsManager(sourceRepo.getOauthTokenSecret()))
                      .owner(sourceRepo.getRepoOwner())
                      .trigger(GitHubTrigger.NONE)
                      .output(sourceOutput)
                      .build()
      );

      final IRole codeBuildRole = loadCodeBuildRole(scope, service, tags, envName, environment);
      final IAction buildAction = new CodeBuildAction(
              CodeBuildActionProps
                      .builder()
                      .actionName(createConstructName(service.getServiceName(), CODEBUILD_SUFFIX))
                      .project(createPipelineProject(scope, ecrRepository, service, codeBuildRole, environment, tags))
                      .input(sourceOutput)
                      .outputs(Arrays.asList(cdkBuildOutput))
                      .role(codeBuildRole)
                      .build()
      );

      final IBaseService ecsFargateService = FargateService.fromFargateServiceAttributes(scope,
              createConstructId(service.getId(), IMPORTED_SERVICE),
              FargateServiceAttributes
                      .builder()
                      .cluster(getCluster(scope, environment, vpc, securityGroups, service.getId()))
                      .serviceName(service.getServiceName())
                      .build()
      );

      final IAction ecsDeployAction = new EcsDeployAction(
              EcsDeployActionProps
                      .builder()
                      .actionName(DEPLOY)
                      .imageFile(cdkBuildOutput.atPath(service.getDeployImageFile()))
                      .service(ecsFargateService)
                      .variablesNamespace(DEPLOY_VARIABLES)
                      .role(codeBuildRole)
                      .build()
      );

      final List<StageProps> stages = Arrays.asList(
              StageProps.builder()
                      .stageName(SOURCE)
                      .actions(Arrays.asList(sourceAction))
                      .build(),
              StageProps.builder()
                      .stageName(BUILD)
                      .actions(Arrays.asList(buildAction))
                      .build(),
              StageProps.builder()
                      .stageName(DEPLOY)
                      .actions(Arrays.asList(ecsDeployAction))
                      .build()
      );

      final IPipeline pipeline = Pipeline.Builder.create(scope, createConstructId(service.getId(), CODEPIPELINE_SUFFIX))
              .crossAccountKeys(false)
              .pipelineName(createConstructName(service.getServiceName(), CODEPIPELINE_SUFFIX))
              .artifactBucket(Bucket.fromBucketArn(scope,
                      createConstructId(service.getId(), PO_CODEPIPELINE_BUCKET),
                      service.getArtifactBucket())
              )
              .stages(stages)
              .role(codeBuildRole)
              .build();

      assignTags(pipeline, tags);

    });

  }

  /**
   * create the Pipeline Project with Buildspec
   */
  private PipelineProject createPipelineProject(final Construct scope, IRepository ecrRepo, EcsFargateService service, IRole codeBuildRole,
                                                final JSONObject environment, final Map<String, String> tags) {
    final PipelineProject pipelineProject = PipelineProject.Builder.create(scope, createConstructId(service.getId(), PIPELINEPROJECT_SUFFIX))
            .projectName(createConstructName(service.getServiceName(), CODE_BUILD_PIPELINEPROJECT_SUFFIX))
            //.badge(true)
            .environment(BuildEnvironment
                    .builder()
                    .buildImage(LinuxBuildImage.STANDARD_2_0)
                    .privileged(true)
                    .build()
            )
            .environmentVariables(new HashMap<>() {{
                put(ECR_NAME, BuildEnvironmentVariable
                        .builder()
                        .value(ecrRepo.getRepositoryName())
                        .build()
                );
                put(DEST_ACCOUNT, BuildEnvironmentVariable
                        .builder()
                        .value(getConfigurationValue(environment, AWS_ACCOUNT_NUMBER))
                        .build()
                );
                put(PIPELINE_BRANCH, BuildEnvironmentVariable
                        .builder()
                        .value(service.getSourceRepo().getRepoBranch())
                        .build()
                );
            }})
            .buildSpec(BuildSpec.fromSourceFilename(BUILD_SPEC))
            .role(codeBuildRole)
            .build();

      assignTags(pipelineProject, tags);

      pipelineProject.addToRolePolicy(new PolicyStatement(PolicyStatementProps
          .builder()
          .effect(Effect.ALLOW)
          .actions(Arrays.asList("sts:AssumeRole"))
          .resources(singletonList("*"))
          .build()
      ));

    return pipelineProject;
  }

  private IRole loadCodeBuildRole(final Construct scope, final EcsFargateService service, final Map<String, String> tags,
                             final String envName, JSONObject environment) {


    final String adminBoundaryArn = getConfigurationValue(environment, ADMIN_BOUNDARY_ARN);

    final String region = getConfigurationValue(environment, REGION);
    final IRole codeBuildRole = Role.Builder.create(scope, createConstructId(service.getId(), CODEBUILD_ROLE_SUFFIX))
            .description("Allows PO Codebuild project to call AWS services on your behalf.")
            .assumedBy(
                    new CompositePrincipal(
                            new ServicePrincipal("codepipeline.amazonaws.com"),
                            new ServicePrincipal("codebuild.amazonaws.com"),
                            new ServicePrincipal("s3.amazonaws.com")
                    )
            )
            .roleName(createConstructName(service.getServiceName(), CODEBUILD_ROLE_SUFFIX + DASH + region))
            .permissionsBoundary(
                    ManagedPolicy
                            .fromManagedPolicyArn(scope, createConstructId(service.getId(), ADMIN_BOUNDARY_CODEBUILD), adminBoundaryArn)
            )
            .build();

    assignTags(codeBuildRole, tags);

    final List<PolicyStatement> policyStatements = Arrays.asList(
            new PolicyStatement(PolicyStatementProps
                    .builder()
                    .actions(singletonList("ecr:*"))
                    .resources(singletonList("*"))
                    .build()
            ),
            new PolicyStatement(PolicyStatementProps
                    .builder()
                    .actions(singletonList("ecs:*"))
                    .resources(singletonList("*"))
                    .build()
            ),
            new PolicyStatement(PolicyStatementProps
                    .builder()
                    .effect(Effect.ALLOW)
                    .actions(singletonList("s3:*"))
                    .resources(singletonList("*"))
                    .build()
            ),
            new PolicyStatement(PolicyStatementProps
                    .builder()
                    .actions(singletonList("ec2:*"))
                    .resources(singletonList("*"))
                    .build()
            ),
            new PolicyStatement(PolicyStatementProps
                    .builder()
                    .actions(Arrays.asList("ssm:Describe*", "ssm:List*", "ssm:Get*", "ssm:Put*"))
                    .resources(singletonList("arn:aws:ssm:*:*:parameter/" + envName +"/po/*"))
                    .build()
            ),
            new PolicyStatement(PolicyStatementProps
                    .builder()
                    .actions(Arrays.asList("secretsmanager:*"))
                    .resources(singletonList("*"))
                    .build()
            ),
            new PolicyStatement(PolicyStatementProps
                    .builder()
                    .actions(Arrays.asList("kms:List*", "kms:Describe*", "kms:Get*", "kms:Decrypt*"))
                    .resources(singletonList("arn:aws:kms:*:*:key/*"))
                    .build()
            ),
            new PolicyStatement(PolicyStatementProps
                    .builder()
                    .actions(Arrays.asList("logs:CreateLogStream", "logs:PutLogEvents"))
                    .resources(singletonList("*"))
                    .build()
            ),
            new PolicyStatement(PolicyStatementProps
                    .builder()
                    .effect(Effect.ALLOW)
                    .actions(Arrays.asList("sts:AssumeRole"))
                    .resources(singletonList("arn:aws:iam::*:role/codePipelineRole*"))
                    .build()
            )
    );
    Policy.Builder.create(scope, createConstructId(service.getId(), CODEBUILD_POLICY_SUFFIX))
            .policyName(createConstructName(service.getServiceName(), CODEBUILD_POLICY_SUFFIX))
            .statements(policyStatements)
            .roles(singletonList(codeBuildRole))
            .build();

    return codeBuildRole;
  }

  public final static void verifyCodePipelineCreationIsEnabled(JSONObject environment) {

    final boolean enableCodePipelineCreation = getConfigurationValue(environment, CREATE_CODEPIPELINE) != null ?
            Boolean.valueOf(getConfigurationValue(environment, CREATE_CODEPIPELINE)) : false;
    if (!enableCodePipelineCreation) {
      throw new UnsupportedOperationException(UNSUPPORTED_ENVIRONMENT_FOR_CODEPIPELINE);
    }
  }
}

