package com.capgroup.po.iac;

import org.json.simple.JSONObject;
import software.amazon.awscdk.core.Construct;
import software.amazon.awscdk.core.Stack;
import software.amazon.awscdk.core.StackProps;

public class POEcsClusterStack extends Stack {

  public POEcsClusterStack(final Construct parent, final String id, JSONObject environment) {
    this(parent, id, null, environment);
  }

  public POEcsClusterStack(final Construct parent, final String id, final StackProps props, JSONObject environment) {
    super(parent, id, props);

    new EcsFargateClusterResource(this, environment);
  }
}
