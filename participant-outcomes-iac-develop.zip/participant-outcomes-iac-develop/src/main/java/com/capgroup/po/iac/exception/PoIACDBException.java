package com.capgroup.po.iac.exception;

/**
 * Parent calculator exception.
 */
public class PoIACDBException extends RuntimeException {

  public PoIACDBException(final String message) {
    super(message);
  }

  public PoIACDBException(final Throwable cause) {
    super(cause);
  }
}