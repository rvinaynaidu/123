package com.capgroup.po.iac;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import software.amazon.awscdk.core.App;

import java.io.FileReader;
import java.util.List;

import static com.capgroup.po.iac.util.CDKUtil.getConfigurationValue;

public final class POStackApp {

  public static void main(final String[] args) throws Exception {
    App app = new App();

    /*
    Get the stack suffix name
     */

    final JSONParser parser = new JSONParser();
    final Object obj = parser.parse(new FileReader("cdk.json"));
    final JSONObject jsonObject = (JSONObject) obj;

    final JSONObject context = getConfigurationValue(jsonObject,"context");
    final List<JSONObject> environments = getConfigurationValue(context, "environments");

    for (JSONObject environment : environments) {
      final String stackSuffix = getConfigurationValue(environment,"stack_suffix");
      new PODbStack(app, "PODatabaseStack" + stackSuffix, environment);
      new POEcsClusterStack(app, "POEcsFargateClusterStack" + stackSuffix, environment);
      new POEcsServicesStack(app, "POEcsFargateServicesStack" + stackSuffix, environment);
      new POCodePipelineStack(app, "POCodePipelineStack" + stackSuffix, environment);
    }
    app.synth();
  }
}
