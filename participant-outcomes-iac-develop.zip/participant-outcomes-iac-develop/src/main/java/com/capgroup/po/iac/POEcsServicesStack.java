package com.capgroup.po.iac;

import org.json.simple.JSONObject;
import software.amazon.awscdk.core.Construct;
import software.amazon.awscdk.core.Stack;
import software.amazon.awscdk.core.StackProps;

import java.io.IOException;

public class POEcsServicesStack extends Stack {

  public POEcsServicesStack(final Construct parent, final String id, JSONObject environment) throws IOException {
    this(parent, id, null, environment);
  }

  public POEcsServicesStack(final Construct parent, final String id, final StackProps props, JSONObject environment) throws IOException {
    super(parent, id, props);

    new EcsFargateServicesResource(this, environment);
  }
}
