package com.capgroup.digital.pss.product.data.services.infra;

import java.util.logging.Logger;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

import com.capgroup.ixt.cdk.configuration.EnvironmentConfiguration;
import com.capgroup.ixt.cdk.resource.IxTFargateECSServiceResource;
import static com.capgroup.ixt.cdk.configuration.ConfigurationUtil.getContextValue;
import com.fasterxml.jackson.databind.ObjectMapper;

import software.amazon.awscdk.core.Construct;
import software.amazon.awscdk.core.Stack;
import software.amazon.awscdk.core.StackProps;
import software.amazon.awscdk.services.apigateway.*;
import software.amazon.awscdk.services.ec2.IInterfaceVpcEndpoint;
// import software.amazon.awscdk.services.ec2.IInterfaceVpcEndpointService;
import software.amazon.awscdk.services.ec2.ISecurityGroup;
import software.amazon.awscdk.services.ec2.ISubnet;
import software.amazon.awscdk.services.ec2.IVpc;
import software.amazon.awscdk.services.ec2.InterfaceVpcEndpoint;
import software.amazon.awscdk.services.ec2.InterfaceVpcEndpointAttributes;
import software.amazon.awscdk.services.ec2.SecurityGroup;
import software.amazon.awscdk.services.ec2.Subnet;
import software.amazon.awscdk.services.ec2.SubnetAttributes;
import software.amazon.awscdk.services.ec2.Vpc;
import software.amazon.awscdk.services.ec2.VpcLookupOptions;
import software.amazon.awscdk.services.iam.Effect;
import software.amazon.awscdk.services.iam.ManagedPolicy;
import software.amazon.awscdk.services.iam.PolicyDocument;
import software.amazon.awscdk.services.iam.PolicyDocumentProps;
import software.amazon.awscdk.services.iam.PolicyStatement;
import software.amazon.awscdk.services.iam.Role;
import software.amazon.awscdk.services.iam.RoleProps;
import software.amazon.awscdk.services.iam.ServicePrincipal;
import software.amazon.awscdk.services.ssm.*;

public class PssProductDataServicesInfraStack extends Stack {
	
	private static final Logger LOGGER = Logger.getLogger(PssProductDataServicesInfraStack.class.getName());



	public PssProductDataServicesInfraStack(Construct scope,
			String stackId,
            StackProps stackProps,
            EnvironmentConfiguration environmentConfiguration,
            ObjectMapper objectMapper) {

		super(scope, stackId, stackProps);
		//Get needed values from configuration json
		System.out.println("===================================================");
		System.out.println(" Basic Configuration from json context");
		System.out.println("===================================================");
		Map<String, Object> albMap = getContextValue(scope.getNode(), "alb");
		System.out.println("ALB URL:");
		String serviceUrl=((ArrayList<String>) albMap.get("host")).get(0);
		System.out.println(serviceUrl);
		Map<String, Object> apiGatewayMap = getContextValue(scope.getNode(), "apiGateway");
		Object corsOrigin=apiGatewayMap.get("corsOrigin");
		System.out.println("CORS Origin:");
		System.out.println(corsOrigin);
		String apiVpcEndpointId=apiGatewayMap.get("vpcEndpointId").toString();
		System.out.println("VPC Endpoint ID:");
		System.out.println(apiVpcEndpointId);
		String apiSecurityGroupId=apiGatewayMap.get("SecurityGroupId").toString();
		System.out.println("VPC Security Group ID:");
		System.out.println(apiSecurityGroupId);
		ArrayList<Map<String, String>> subnetArray = getContextValue(scope.getNode(), "subnetGroups");
		System.out.println("Subnets:");
		System.out.println(subnetArray);
		try {
			//Create Container
			System.out.println("===================================================");
			System.out.println(" Building Container");
			System.out.println("===================================================");
			IxTFargateECSServiceResource ECS = new IxTFargateECSServiceResource(
					this,
					stackId,
					environmentConfiguration,
					objectMapper
			);

			//Create API Gateway
			//Create CloudWatch Role
			System.out.println("===================================================");
			System.out.println(" Creating Cloudwatch Role");
			System.out.println("===================================================");
			Role apiCloudWatchRole =
				new Role(
					this,
					stackId+"CloudwatchRole",
					new RoleProps.Builder()
						.assumedBy(new ServicePrincipal("apigateway.amazonaws.com"))
						.managedPolicies(Arrays.asList(
							ManagedPolicy.fromAwsManagedPolicyName(
								"service-role/AmazonAPIGatewayPushToCloudWatchLogs")))
						.permissionsBoundary(ManagedPolicy.fromManagedPolicyArn(
							this,
							stackId+"CloudwatchBoundary",
							"arn:aws:iam::"+this.getAccount()+":policy/AdminPermissionsBoundary"))
						.build()
				);
			System.out.println("API CloudWatch Role:");
			System.out.println(apiCloudWatchRole.toString());

			//All the API Configuration
			System.out.println("===================================================");
			System.out.println(" Building API Configuration");
			System.out.println("===================================================");
			CorsOptions defaultCorsOptions = 
				new CorsOptions.Builder()
					.allowOrigins(Cors.ALL_ORIGINS)
					.allowCredentials(true)
					.allowHeaders(Arrays.asList(
						"Content-Type",
						"X-Amz-Date",
						"Authorization",
						"X-Api-Key",
						"X-Amz-Security-Token",
						"return-format",
						"page-size",
						"page-offset",
						"page-merge"))
					.build();
			System.out.println("CORS Options:");
			System.out.println(defaultCorsOptions.toString());

			IVpc apiVpc = Vpc.fromLookup(this, stackId+"Vpc", 
				VpcLookupOptions.builder()
					.vpcId(getContextValue(scope.getNode(), "vpcId"))
					.build()
				);
			System.out.println("API VPC:");
			System.out.println(apiVpc.toString());
			
			List<ISubnet> apiSubnets = new ArrayList<ISubnet>();
			
			for (int i = 0; i < subnetArray.size(); i++) {
				System.out.println(subnetArray.get(i));
				apiSubnets.add((ISubnet) Subnet.fromSubnetAttributes(this, 
					stackId+"Subnet"+i,
					new SubnetAttributes.Builder()
						.availabilityZone(subnetArray.get(i).get("az"))
						.subnetId(subnetArray.get(i).get("subnetId"))
						.build()
					)
				);
			}
			System.out.println("API Subnets:");
			for (int i = 0; i < apiSubnets.size(); i++) {
				System.out.println((apiSubnets.get(i)).getSubnetId());
			}

			List<ISecurityGroup> apiSecurityGroups = new ArrayList<ISecurityGroup>();

			apiSecurityGroups.add(SecurityGroup.fromSecurityGroupId(this, "apiSecurityGroupId", apiSecurityGroupId));

			IInterfaceVpcEndpoint apiVpcEndpoint = 
				InterfaceVpcEndpoint.fromInterfaceVpcEndpointAttributes(
					this,
					stackId+"ApiVpcEndpoint",
					new InterfaceVpcEndpointAttributes.Builder()
						.port(443)
						.vpcEndpointId(apiVpcEndpointId)
						//.securityGroupId(apiSecurityGroupId)
						.securityGroups(apiSecurityGroups)
						.build()
			);

			System.out.println("API VPC Endpoint:");
			System.out.println(apiVpcEndpoint.getVpcEndpointId());

			EndpointConfiguration defaultEndpointConfiguration =
				new EndpointConfiguration.Builder()
						.types(Arrays.asList(EndpointType.PRIVATE))
						.vpcEndpoints(Arrays.asList(apiVpcEndpoint))
						.build();

			Object apiCondition = Map.of("aws:SourceVpce", apiVpcEndpoint.getVpcEndpointId());

			PolicyStatement apiDenyPolicy= new PolicyStatement();
			apiDenyPolicy.addAnyPrincipal();
			apiDenyPolicy.addActions("execute-api:Invoke");
			apiDenyPolicy.addResources("execute-api:/*");
			apiDenyPolicy.setEffect(Effect.DENY);
			apiDenyPolicy.addCondition("StringNotEqual", apiCondition);

			PolicyStatement apiAllowPolicy= new PolicyStatement();
			apiAllowPolicy.addAnyPrincipal();
			apiAllowPolicy.addActions("execute-api:Invoke");
			apiAllowPolicy.addResources("execute-api:/*");
			apiAllowPolicy.setEffect(Effect.ALLOW);

			List<PolicyStatement> apiPolicyList = new ArrayList<PolicyStatement>();
			apiPolicyList.add(apiDenyPolicy); //Deny Policy is not working
			apiPolicyList.add(apiAllowPolicy);

			PolicyDocument apiPolicy = new PolicyDocument(
				PolicyDocumentProps.builder()
				.statements(apiPolicyList)
				.build()
			);

			System.out.println("API Gateway Policy:");
			System.out.println(apiPolicy.toJSON());
			System.out.println("Validation:");
			System.out.println(apiPolicy.validateForResourcePolicy());

			//The Actual API
			System.out.println("===================================================");
			System.out.println(" Building API");
			System.out.println("===================================================");
			RestApi api = new RestApi(
					this,
					stackId+"ApiGateway",
					 new RestApiProps.Builder()
					 	.defaultCorsPreflightOptions(defaultCorsOptions)
						.cloudWatchRole(false)
						.endpointConfiguration(defaultEndpointConfiguration)
						.policy(apiPolicy)
						.deployOptions(
							new StageOptions.Builder()
								.stageName(environmentConfiguration.getName())
								.build()
						)
					 	.build()
			);

			System.out.println("API Gateway:");
			System.out.println(api.toString());

			//Add Cloudwatch role to API Gateway

			CfnAccount apiAccount = new CfnAccount(
				this, 
				stackId+"ApiAccount"
				
			);
			apiAccount.setCloudWatchRoleArn(apiCloudWatchRole.getRoleArn());;

			//API Key Setup
			ApiKey defaultApiKey = new ApiKey(
				this, 
				"defaultApiKey",
				ApiKeyProps.builder()
					.apiKeyName(stackId+"ApiKey")
					.enabled(true)
					.build()
			);

			UsagePlanProps defaultUsagePlanProps = UsagePlanProps.builder()
				.name("UsagePlan"+stackId+environmentConfiguration.getName())
				.apiKey(defaultApiKey)
				.apiStages(List.of(new UsagePlanPerApiStage.Builder()
					.api(api)
					.stage(api.getDeploymentStage())
					.build()))
				.build();

			api.addUsagePlan("UsagePlan",defaultUsagePlanProps);

			//Create Resources on the API Gateway
			IResource apiroot = api.getRoot();

			Resource ppdsResource = apiroot.addResource("ppds");

			Resource ppdsHelloWorldResource = ppdsResource.addResource("hello-world");

			HttpIntegration ppdsHelloWorldIntegration = new HttpIntegration("https://"+serviceUrl+"/hello-world");

			ppdsHelloWorldResource.addMethod("GET", ppdsHelloWorldIntegration);
			
			//ppdsResource.addMethod("POST");

			new StringParameter(this, stackId+"ApiUrlInternal", 
				new StringParameterProps.Builder()
					.parameterName(stackId+"ApiUrlInternal")
					.stringValue(api.getUrl())
					.build()
			);
			new StringParameter(this, stackId+"ApiUrlExternal", 
				new StringParameterProps.Builder()
					.parameterName(stackId+"ApiUrlExternal")
					.stringValue(api.getRestApiId()+"-"+apiVpcEndpointId+".execute-api."+this.getRegion()+".amazonaws.com/")
					.build()
			);
			new StringParameter(this, stackId+"APIKeyID", 
				new StringParameterProps.Builder()
					.parameterName(stackId+"APIKeyID")
					.stringValue(defaultApiKey.getKeyId())
					.build()
			);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
     }
}
