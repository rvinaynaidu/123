"""
  A custom resource to create a customize prefixlist for FLEX

    NewPrefixListTransferSFTP:
    Type: Custom::CreatePrefixList
    Properties:
      ServiceToken: !Sub 'arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:cfn-prefixlist-provision'
      PrefixListName: !Sub "${ApplicationShortName}-pl-${PrefixListIdentifier}"
      CidrRange: !Ref CidrRange
      CidrDescription: !Ref CidrDescription
      ApplicationShortName: !Ref 'ApplicationShortName'
      AssetID: !Ref 'AssetID'
      CostCenter: !Ref 'CostCenter'
      Environment: !Ref 'Environment'
      ApplicationName: !Ref 'ApplicationName'
      AppCode: !Ref 'AppCode'
      ProjectCode: !Ref 'ProjectCode'
      Lifecycle: !Ref 'Lifecycle'
"""

from __future__ import print_function
import logging
import boto3
import json
from crhelper import CfnResource
from datetime import datetime

logger = logging.getLogger(__name__)
# Initialise the helper, all inputs are optional, this example shows the defaults
helper = CfnResource(json_logging=False, log_level='DEBUG', boto_level='CRITICAL')

try:
    ec2_client = boto3.client('ec2')
except Exception as e:
    helper.init_failure(e)


def create_prefix_list(prefix_list_name, max_entries, entries, address_family, tags):
    logger.info(f'Create Prefix list with prefix list name {prefix_list_name}')
    return ec2_client.create_managed_prefix_list(
        PrefixListName=prefix_list_name,
        Entries=entries,
        MaxEntries=int(max_entries),
        TagSpecifications=[
            {
                'ResourceType': 'prefix-list',
                'Tags': tags
            },
        ],
        AddressFamily=address_family
    )


def list_prefix_lists(filters=None):
    if filters is None:
        filters = []
    logger.info('List prefix lists')
    if not filters:
        return ec2_client.describe_managed_prefix_lists()
    else:
        return ec2_client.describe_managed_prefix_lists(
        Filters=filters
        )


def delete_prefix_list(prefix_list_id):
    return ec2_client.delete_managed_prefix_list(
        PrefixListId=prefix_list_id
    )


def get_tags_list(tags):
    tag_list = []
    for key in tags:
        tag_list.append(
            {
                'Key': key,
                'Value': tags[key]
            }
        )
    return tag_list


def format_json(data):
    return json.dumps(data, default=lambda d: d.isoformat() if isinstance(d, datetime.datetime) else str(d))


def get_cidr_entries(cidr_list, cidr_desc_list):
    cidr_entries = []
    if cidr_list is not None:
        for i in range(len(cidr_list)):
            cidr_entries.append(
                {
                    "Cidr": cidr_list[i],
                    "Description": cidr_desc_list[i]

                }
            )
    return cidr_entries


@helper.create
def create(event, context):
    logger.info("Received create event: %s" % format_json(event))

    prefix_list_name = event['ResourceProperties']['PrefixListName']
    app_short_name = event['ResourceProperties']['ApplicationShortName']
    asset_id = event['ResourceProperties']['AssetID']
    cost_center = event['ResourceProperties']['CostCenter']
    env = event['ResourceProperties']['Environment']
    app_name = event['ResourceProperties']['ApplicationName']
    app_code = event['ResourceProperties']['AppCode']
    project_code = event['ResourceProperties']['ProjectCode']
    lifecycle = event['ResourceProperties']['Lifecycle']
    #address_family = event['ResourceProperties']['AddressFamily']

    tags = eval('{ "CostCenter": "' + cost_center + '", \
                    "AssetID": "' + asset_id + '" , \
                    "AppCode": "' + app_code + '", \
                    "ApplicationName": "' + app_name + '", \
                    "Environment": "' + env + '" , \
					"ProjectCode": "' + project_code + '" , \
					"Lifecycle": "' + lifecycle + '" , \
                    "ApplicationShortName": "' + app_short_name + '"}')

    cidr_range_list = event['ResourceProperties']['CidrRange']
    cidr_description_list = event['ResourceProperties']['CidrDescription']

    # 1) Parse the CidrRange list
    # 2) Parse the CidrDescription
    # 3) Find the total entries to set maxentries values
    print(len(cidr_range_list))
    print(len(cidr_description_list))
    if not cidr_range_list:
        raise ValueError("CIDR range list cannot be empty")
    elif not cidr_description_list:
        raise ValueError("CIDR description list cannot be empty")
    #elif len(cidr_range_list) != len(cidr_description_list):
        #raise ValueError("CIDR range list and description list count doesn't match")

    prefix_list_id = None

    max_entries = len(cidr_range_list)
    cidr_list = get_cidr_entries(cidr_range_list, cidr_description_list)
    #if address_family is None:
    address_family = "IPv4"
    logger.info(cidr_list)
    logger.info(f' Max entries {max_entries}')
    tags_list = get_tags_list(tags)
    prefix_list_response = create_prefix_list(prefix_list_name, max_entries, cidr_list, address_family, tags_list)
    logger.info(f'Prefix List response {prefix_list_response}')
    if prefix_list_response is not None:
        prefix_list_id = prefix_list_response["PrefixList"]["PrefixListId"]
    return prefix_list_id


@helper.update
def update(event, context):
    logger.info("Received update event: %s" % format_json(event))
    resource_props = event.get('ResourceProperties')
    prefix_list_name = resource_props["PrefixListName"]
    prefix_list_id = resource_props["PhysicalResourceId"]
    filters = [
        {
            'Name': 'prefix-list-name',
            'Values': [
                prefix_list_name,
            ]
        }
    ]
    list_response = list_prefix_lists(filters)
    logger.info(list_response)


@helper.delete
def delete(event, context):
    logger.info("Received delete event: %s" % format_json(event))
    resource_props = event.get('ResourceProperties')
    if resource_props is None:
        raise Exception("Resource Properties cannot be empty")
    logger.info('Received properties %s' % format_json(resource_props))
    prefix_list_name = resource_props["PrefixListName"]
    prefix_list_id = event.get("PhysicalResourceId")
    if prefix_list_id:
        logger.info(f'Prefix List Id to be deleted {prefix_list_id}')
        delete_response = delete_prefix_list(prefix_list_id)
        logger.info(delete_response)
    else:
        logger.error("Prefix List ID is None or not found")


def handler(event, context):
    helper(event, context)
