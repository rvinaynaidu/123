package com.capgroup.digital.pdftemplate.infrastructure.itext;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;

import com.capgroup.digital.pdftemplate.ThymeleafConfig;
import com.capgroup.digital.pdftemplate.domain.model.Report;
import com.capgroup.digital.pdftemplate.domain.model.Format;
import com.capgroup.digital.pdftemplate.domain.model.element.RunningElement;
import com.capgroup.digital.pdftemplate.domain.model.element.RunningElementType;
import com.capgroup.digital.pdftemplate.domain.service.ReportService;
import com.itextpdf.forms.PdfPageFormCopier;
import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.kernel.events.PdfDocumentEvent;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.licensekey.LicenseKey;

@Service
public class ItextPdfService implements ReportService {
	
    @Autowired
    private ThymeleafConfig config;
	private static final String PAGENUMBER = "pageNumber";
	private static final String PAGEBREAKSTATUS = "pageBreakStatus";
 	private ConverterProperties properties = new ConverterProperties();
 	private Context context = new Context();
 	private PdfPageFormCopier copier = new PdfPageFormCopier();
 	
 	@Value("${investor.templatePath}")
	private String investorTemplatePath;
 	
 	@Value("${investor.ABSFontPath}")
	private String investorABSFontPath;
 	
 	@Override
	public byte[] testPDF() throws IOException {
		
		properties.setBaseUri(getResources());
        String[] samplePages = {"sample"};
        
        ByteArrayOutputStream output = new ByteArrayOutputStream();
    	PdfWriter writer = new PdfWriter(output);
    	PdfDocument pdf = new PdfDocument(writer);
    	
    	combinePages(pdf, samplePages, context, Format.LANDSCAPE);
    	
    	pdf.close();
    	return output.toByteArray();
	}
	
 	@Override
	public byte[] createPDF(Report data, Format format, List<RunningElementType> elements) throws IOException, FontFormatException {
		
		loadItext7License();
		
		properties.setBaseUri(getResources());
        context.setVariables(data.getData());
        String[] pages = data.getTemplates();
        
        if(Arrays.asList(pages).contains(investorTemplatePath)){
        	boolean pageBreakStatus = checkPageBreakStatus(data);
            context.setVariable(PAGEBREAKSTATUS, pageBreakStatus);
        }
        
        ByteArrayOutputStream output = new ByteArrayOutputStream();
    	PdfWriter writer = new PdfWriter(output);
    	PdfDocument pdf = new PdfDocument(writer);
    	
    	combinePages(pdf, pages, context, format);
    	
    	try(Document doc = new Document(pdf)) {
	    	if(elements.contains(RunningElementType.HEADER)) {
	    		addRunningElement(pdf, doc, RunningElementType.HEADER, data.getHeader());
	    	}
	    	if(elements.contains(RunningElementType.FOOTER)) {
	    		addRunningElement(pdf, doc, RunningElementType.FOOTER, data.getFooter());
	    	}
    	}
    	
    	pdf.close();
        return output.toByteArray();
        
    }
    
	private void combinePages(PdfDocument parent, String[] pages, Context variables, Format format) throws IOException {
		int count = 1;
    	for (String html : pages) {
    		variables.setVariable(PAGENUMBER, count);
    		String processedHtml = config.templateEngine().process(html, variables);
    		ByteArrayOutputStream baos = new ByteArrayOutputStream();
    		PdfDocument temp = new PdfDocument(new PdfWriter(baos));
    		
    		count++;
    		
    		if(format != null && format.equals(Format.LANDSCAPE)) {
    			temp.setDefaultPageSize(PageSize.A4.rotate());
    		}
    		
			HtmlConverter.convertToPdf(processedHtml, temp, properties);
            temp = new PdfDocument(new PdfReader(new ByteArrayInputStream(baos.toByteArray())));
            temp.copyPagesTo(1, temp.getNumberOfPages(), parent, copier);
            temp.close();
    	}
	}
	
	/*
	 * Check condition for page break based on Number of Lines of 
	 * Registration Block and Fund Table
	 */
	private boolean checkPageBreakStatus(Report data) throws FontFormatException, IOException {
		boolean pageBreakStatus = false;
		int maxLinesInOnePage = 45;
		int lowerCountLimit = 15;
		int upperCountLimit = 20;
		
		List<Map<String, String>> fundList = new ArrayList<>((List) data.getData().get("funds"));
		int fundsBlockLinesCount = getFundsLineCount(fundList);
		Map<String, String> registrationMap = new HashMap<>((Map<String, String>)data.getData().get("accountRegistration"));
		int registrationBlockLinesCount = (int) registrationMap.values().stream().filter(v -> v != null && !v.isEmpty()).count();
		int dynamicLinesCount = registrationBlockLinesCount + fundsBlockLinesCount;
		
		/* 
		 * '%46' is to check page break for multiple pages
		 * A single page can accommodate maximum 45 dynamicLines
		 * for Two page:
		 *  if dynamicLinesCount is in range(15-20) inclusive, pagebreak should happen
		 */
		if((dynamicLinesCount % maxLinesInOnePage)>=lowerCountLimit && (dynamicLinesCount % maxLinesInOnePage)<=upperCountLimit) {
			pageBreakStatus = true;
		}
		else {
			pageBreakStatus = false;
		}
		return pageBreakStatus;
	}

	
	/* 
	 * We get Number of  Fund Field  displayed in PDF Document using this method
	 * we check following two conditions:
	 * 	1. for counting Fund fields in generated PDF we count fundName in processed html because
	 * 	each FundField has a single fundName
	 * 	2. we check fundName width if fundName width including whitespace character is 
	 * 	more than 340 then it will come in the next line in generated pdf, so we count it as a seperate line
	 */
	private int getFundsLineCount (List<Map<String, String>> fundList) throws FontFormatException, IOException {
		int fundLineCount = 0;  
		int maxOneLineFundNameWidth = 340;
		Graphics2D graphics = (new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB)).createGraphics();
		Path path = Paths.get(URI.create(getClass().getResource(investorABSFontPath).toString()));
		Font font = Font.createFont(Font.TRUETYPE_FONT, new File(path.toString())).deriveFont(15.5f);
		FontMetrics fontMatrics = graphics.getFontMetrics(font);
		for(Map<String, String> fund:fundList) {
			if (fund != null) {
				String fundName = fund.get("name");
				int fundNameWidth = fontMatrics.stringWidth(fundName);
				if(fundNameWidth > maxOneLineFundNameWidth) {
					fundLineCount += fundNameWidth / maxOneLineFundNameWidth;
				}
				fundLineCount += 1;
			}
		}
		return fundLineCount;
	}
	
	private void addRunningElement(PdfDocument pdf, Document doc, RunningElementType runningElementType, RunningElement runningElement) {
        if(runningElementType.equals(RunningElementType.HEADER)) {
        	pdf.addEventHandler(PdfDocumentEvent.END_PAGE, new HeaderEvent(doc, runningElement));
        }
        if(runningElementType.equals(RunningElementType.FOOTER)) {
        	pdf.addEventHandler(PdfDocumentEvent.END_PAGE, new FooterEvent(doc, runningElement));
        }
	}
	
    private String getResources() {
    	URL url = getClass().getResource("/static/");
    	return url.toString();
    }
	
    private void loadItext7License() throws IOException {
    	URL url = getClass().getResource("/itextkeys/");
    	Path path = Paths.get(URI.create(url.toString())); 
    	try (Stream<Path> paths = Files.walk(path)) {
    		List<String> result = paths.filter(Files::isRegularFile)
    				.map(Path::toString).collect(Collectors.toList());
    		String[] keys = new String[result.size()];
    		for(int i = 0; i < result.size(); i++) {
    			keys[i] = result.get(i);
    		}
        	LicenseKey.loadLicenseFile(keys);
    	} 
    }

}
