package com.capgroup.digital.pdftemplate.domain.model.element;

public enum ElementType {

	TITLE,
	PAGINATION
	
}
