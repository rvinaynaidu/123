package com.capgroup.digital.pdftemplate.domain.model;

import java.util.Map;

import com.capgroup.digital.pdftemplate.domain.model.element.RunningElement;

public class Report {

	private String[] templates;
	private RunningElement header;
	private RunningElement footer;
	private Map<String, Object> data;
	
	public String[] getTemplates() {
		return templates;
	}
	public void setTemplates(String[] templates) {
		this.templates = templates;
	}
	public RunningElement getHeader() {
		return header;
	}
	public void setHeader(RunningElement header) {
		this.header = header;
	}
	public RunningElement getFooter() {
		return footer;
	}
	public void setFooter(RunningElement footer) {
		this.footer = footer;
	}
	public Map<String, Object> getData() {
		return data;
	}
	public void setData(Map<String, Object> data) {
		this.data = data;
	}

}
