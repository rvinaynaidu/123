package com.capgroup.digital.pdftemplate.domain.model;

import com.fasterxml.jackson.annotation.JsonValue;

public enum Position {

	LEFT,
	CENTER,
	RIGHT;

	@JsonValue
	public String getPosition() {
		return this.toString();
	}
	
}
