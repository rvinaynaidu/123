package com.capgroup.digital.pdftemplate.infrastructure.itext;

import com.capgroup.digital.pdftemplate.domain.model.Position;
import com.capgroup.digital.pdftemplate.domain.model.element.Element;
import com.capgroup.digital.pdftemplate.domain.model.element.ElementType;
import com.capgroup.digital.pdftemplate.domain.model.element.RunningElement;
import com.itextpdf.kernel.events.Event;
import com.itextpdf.kernel.events.IEventHandler;
import com.itextpdf.kernel.events.PdfDocumentEvent;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.layout.Canvas;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.property.TextAlignment;


public class FooterEvent implements IEventHandler {

	protected Document doc;
	protected RunningElement runningElement;
	
	private float pageMarginHeight = 30;
	private float pageMarginWidth = 35;
	private int totalPages;
	 
    public FooterEvent(Document doc) {
        this.doc = doc;
    }
    
    public FooterEvent(Document doc, RunningElement footer) {
        this.doc = doc;
        this.runningElement = footer;
    }
	
    @Override
    public void handleEvent(Event event) {
    	PdfDocumentEvent docEvent = (PdfDocumentEvent) event;
		PdfDocument pdf = docEvent.getDocument();
		PdfPage page = docEvent.getPage();
		Rectangle pageSize = page.getPageSize();
		PdfCanvas pdfCanvas = new PdfCanvas(page.getLastContentStream(), page.getResources(), pdf);
		Canvas canvas = new Canvas(pdfCanvas, pdf, pageSize);
		
		if(runningElement.getTitle() != null) {
			setElementPages(pdf, page, canvas, pageSize, ElementType.TITLE, runningElement.getTitle());
		}
		
		if(runningElement.getPagination() != null) {
			setElementPages(pdf, page, canvas, pageSize, ElementType.PAGINATION, runningElement.getPagination());
		}

		canvas.close();
    }
    
    private void setElementPages(PdfDocument pdf, PdfPage page, Canvas canvas, Rectangle pageSize, ElementType elementType, Element element) {
    	int pageNumber = pdf.getPageNumber(page);
    	totalPages = pdf.getNumberOfPages();
    	canvas.setFontSize(element.getFontSize());
    	
    	if(!element.isIncludeFirstPage()) {
    		if(page != pdf.getFirstPage()) {
    			setElementPosition(canvas, pageNumber, pageSize, elementType, element);
    		}
    	} else {
    		setElementPosition(canvas, pageNumber, pageSize, elementType, element);
    	}
    }
    
    private void setElementPosition(Canvas canvas, int pageNumber, Rectangle pageSize, ElementType elementType, Element element) {
		float pageHeight = pageSize.getBottom() + pageMarginHeight;

		if(element.getPosition().equals(Position.RIGHT)) {
			float pageRight = pageSize.getRight() - pageMarginWidth;
			if(elementType.equals(ElementType.TITLE)) {
				insertTitleElement(canvas, element.getText(), pageRight, pageHeight, TextAlignment.RIGHT); 
			} else {
				insertPaginationElement(canvas, element.getText(), pageNumber, pageRight, pageHeight, TextAlignment.RIGHT);
			}						
		} else if(element.getPosition().equals(Position.LEFT)) {
			float pageLeft = pageSize.getLeft() + pageMarginWidth;
			if(elementType.equals(ElementType.TITLE)) {
				insertTitleElement(canvas, element.getText(), pageLeft, pageHeight, TextAlignment.LEFT); 
			} else {
				insertPaginationElement(canvas, element.getText(), pageNumber, pageLeft, pageHeight, TextAlignment.LEFT);
			}
		} else if(element.getPosition().equals(Position.CENTER)) {
			float pageCenter = pageSize.getLeft() + pageSize.getRight() / 2;
			if(elementType.equals(ElementType.TITLE)) {
				insertTitleElement(canvas, element.getText(), pageCenter, pageHeight, TextAlignment.CENTER); 
			} else {
				insertPaginationElement(canvas, element.getText(), pageNumber, pageCenter, pageHeight, TextAlignment.CENTER);
			}
		}
    }
    
    private void insertTitleElement(Canvas canvas, String text, float x, float y, TextAlignment alignment) {
		canvas.showTextAligned(text, x, y, alignment);
    }
    
    private void insertPaginationElement(Canvas canvas, String text, int pageNumber, float x, float y, TextAlignment alignment) {
    	if(this.runningElement.getPagination().includePaginatedFooter()) {
			canvas.showTextAligned(text + " " + pageNumber + " of " + totalPages , x, y, alignment);
		} else {
			canvas.showTextAligned(text + " " + pageNumber, x, y, alignment);
		}
    }
}
