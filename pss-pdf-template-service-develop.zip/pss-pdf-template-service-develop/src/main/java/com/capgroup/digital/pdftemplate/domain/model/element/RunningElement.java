package com.capgroup.digital.pdftemplate.domain.model.element;

public class RunningElement {

	private Element title;
	private Element pagination;

	public Element getTitle() {
		return title;
	}
	public void setTitle(Element title) {
		this.title = title;
	}
	public Element getPagination() {
		return pagination;
	}
	public void setPagination(Element pagination) {
		this.pagination = pagination;
	}
	
}
