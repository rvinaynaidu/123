package com.capgroup.digital.pdftemplate.domain.model;

import com.fasterxml.jackson.annotation.JsonValue;

public enum Format {

	NONE,
	STANDARD,
	LANDSCAPE;
	
	@JsonValue
	public String getFormat() {
		return this.toString();
	}
	
}
