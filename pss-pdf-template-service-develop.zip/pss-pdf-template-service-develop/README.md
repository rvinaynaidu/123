# PDF Template Service

PDF generation service through templates that exist on service side and interpolate data through REST API

## Owner

Team: **Nirvana**

## Documentation
[PDF Template Service](https://confluence.capgroup.com/display/DIGPD/PDF+Template+Service)
