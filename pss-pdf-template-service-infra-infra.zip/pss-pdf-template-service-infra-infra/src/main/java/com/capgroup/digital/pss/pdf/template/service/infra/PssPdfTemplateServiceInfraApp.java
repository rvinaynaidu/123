package com.capgroup.digital.pss.pdf.template.service.infra;

import java.util.Map;
import java.util.Objects;
import java.util.logging.Logger;

import com.capgroup.ixt.cdk.configuration.EnvironmentConfiguration;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import software.amazon.awscdk.core.App;
import software.amazon.awscdk.core.Environment;
import software.amazon.awscdk.core.StackProps;

import static com.capgroup.ixt.cdk.configuration.ConfigurationUtil.getContextValue;

public class PssPdfTemplateServiceInfraApp {
	
	public static final String ENVIRONMENT_CONFIGURATION_KEY = "environment";
	private static final ObjectMapper mapper = new ObjectMapper();
	private static final Logger LOG = Logger.getLogger(PssPdfTemplateServiceInfraApp.class.getName());
	
	static {
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}
	
	public static void main(final String[] args) throws JsonMappingException, JsonProcessingException {
		
		App app = new App();
        Map<String, String> environmentMap = getContextValue(app.getNode(), ENVIRONMENT_CONFIGURATION_KEY);
        EnvironmentConfiguration environmentConfiguration = mapper.convertValue(environmentMap, EnvironmentConfiguration.class);

        Environment environment = Environment
            .builder()
            .account(environmentConfiguration.getAccount())
            .region(environmentConfiguration.getRegion())
            .build();

        StackProps stackProps = StackProps
            .builder()
            .env(environment)
            .build();
        
		new PssPdfTemplateServiceInfraStack(app, "PssPdfTemplateServiceStack",
				stackProps,environmentConfiguration, mapper);
		
		app.synth();
	}


}
