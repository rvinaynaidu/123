package com.capgroup.digital.pss.pdf.template.service.infra;

import java.util.logging.Logger;

import com.capgroup.ixt.cdk.configuration.EnvironmentConfiguration;
import com.capgroup.ixt.cdk.resource.IxTFargateECSServiceResource;
import com.fasterxml.jackson.databind.ObjectMapper;

import software.amazon.awscdk.core.Construct;
import software.amazon.awscdk.core.Stack;
import software.amazon.awscdk.core.StackProps;

public class PssPdfTemplateServiceInfraStack extends Stack {
	
	private static final Logger LOGGER = Logger.getLogger(PssPdfTemplateServiceInfraStack.class.getName());



	public PssPdfTemplateServiceInfraStack(Construct scope,
			String stackId,
            StackProps stackProps,
            EnvironmentConfiguration environmentConfiguration,
            ObjectMapper objectMapper) {

		super(scope, stackId, stackProps);

		try {
			new IxTFargateECSServiceResource(
					this,
					stackId,
					environmentConfiguration,
					objectMapper
			);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
     }
}
	

