package com.capgroup.digital.product.data.services.application.impl;

import com.capgroup.digital.product.data.services.data.factset.FactSetClientImpl;
import com.capgroup.digital.product.data.services.data.factset.FactSetSecurity;
import com.capgroup.digital.product.data.services.data.factset.annotation.FactSetConverter;
import com.capgroup.digital.product.data.services.data.factset.annotation.FactSetConverterImpl;
import com.capgroup.digital.product.data.services.exception.NetworkException;
import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.ResourceUtils;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class FactSetClientImplTest {

    private static final String SAMPLES_PATH = "classpath:response/";

    @Mock
    private HttpResponse httpResponse;
    @Mock
    private FactSetSecurity factSetSecurity;
    @Spy
    private final FactSetConverter factSetConverter = new FactSetConverterImpl();
    @Mock
    private HttpClient httpClient;
    @InjectMocks
    private FactSetClientImpl factSetClientImpl;

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(factSetClientImpl, "metadataUrl", "https://api.factset.com/analytics/pub-datastore/swivel/v1/FCR_REPORTING/API_Doc.PA3/report1595a97c-d43d-51a2-2824-56d59a3e04e9/tile0bcc5c6b-e05d-e9ca-089a-57a5868744cf/");
        ReflectionTestUtils.setField(factSetClientImpl, "statsUrl", "https://api.factset.com/analytics/pub-datastore/swivel/v1/FCR_REPORTING/API_Doc.SPAR3/1jmqSl7XdJ0/2bAF85DkWfs/");
        ReflectionTestUtils.setField(factSetClientImpl, "lifetimeReturnsUrl", "https://api.factset.com/analytics/pub-datastore/swivel/v1/FCR_REPORTING/API_Doc.SPAR3/2SHuyvoNbZn/2bAF85DkWfs/");
    }

    @Test
    public void should_get_product_metadata_exception() throws Exception {
        given(factSetSecurity.getToken()).willReturn("Bearer token");
        given(httpClient.send(any(HttpRequest.class),any(HttpResponse.BodyHandler.class))).willThrow(new IOException());

        Assertions.assertThrows(NetworkException.class, () ->
                factSetClientImpl.getProductMetaData("MorningstarId"));
    }

    @Test
    public void should_get_product_metadata_serialize_exception() throws Exception {
        var file = ResourceUtils.getFile(SAMPLES_PATH + "metadataResponse.json");
        var json = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
        given(httpResponse.body()).willReturn(json);
        given(factSetSecurity.getToken()).willReturn("Bearer token");
        given(httpClient.send(any(HttpRequest.class),any(HttpResponse.BodyHandler.class))).willReturn(httpResponse);
        doThrow(new IndexOutOfBoundsException()).when(factSetConverter).convert(any(Class.class),anyList(), anyList());
        Assertions.assertThrows(RuntimeException.class, () ->
                factSetClientImpl.getProductMetaData("MorningstarId"));
    }

    @Test
    public void should_get_product_metadata() throws Exception {
        var file = ResourceUtils.getFile(SAMPLES_PATH + "metadataResponse.json");
        var json = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
        given(httpResponse.body()).willReturn(json);
        given(factSetSecurity.getToken()).willReturn("Bearer token");
        given(httpClient.send(any(HttpRequest.class),any(HttpResponse.BodyHandler.class))).willReturn(httpResponse);

        var result = factSetClientImpl.getProductMetaData("MorningstarId");
        Assertions.assertEquals( "American Funds AMCAP A", result.getMorningstarName());
        Assertions.assertEquals("26.9937801361084", result.getOneYearMonthlyLoadAdjustedReturn());
        Assertions.assertEquals("-0.00999999977648258", result.getThirtyDayYield());
        Assertions.assertEquals("0.680000007152557", result.getNetExpenseRatio());
    }

    @Test
    public void should_get_product_statistics_exception() throws Exception {
        given(factSetSecurity.getToken()).willReturn("Bearer token");
        given(httpClient.send(any(HttpRequest.class),any(HttpResponse.BodyHandler.class))).willThrow(new IOException());

        Assertions.assertThrows(NetworkException.class, () ->
                factSetClientImpl.getProductStatistics("MorningstarId"));
    }

    @Test
    public void should_get_product_statistics_serialize_exception() throws Exception {
        var file = ResourceUtils.getFile(SAMPLES_PATH + "statisticsResponse.json");
        var json = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
        given(httpResponse.body()).willReturn(json);
        given(factSetSecurity.getToken()).willReturn("Bearer token");
        given(httpClient.send(any(HttpRequest.class),any(HttpResponse.BodyHandler.class))).willReturn(httpResponse);
        doThrow(new IndexOutOfBoundsException()).when(factSetConverter).convert(any(Class.class),anyList(), anyList());
        Assertions.assertThrows(RuntimeException.class, () -> factSetClientImpl.getProductStatistics("MorningstarId"));
    }

    @Test
    public void should_get_product_statistics() throws Exception {
        var file = ResourceUtils.getFile(SAMPLES_PATH + "statisticsResponse.json");
        var json = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
        given(httpResponse.body()).willReturn(json);
        given(factSetSecurity.getToken()).willReturn("Bearer token");
        given(httpClient.send(any(HttpRequest.class),any(HttpResponse.BodyHandler.class))).willReturn(httpResponse);

        var result = factSetClientImpl.getProductStatistics("MorningstarId");
        Assertions.assertEquals( "34.7414129697894", result.getOneYearMonthlyAnnualizedReturnNav());
    }

    @Test
    public void should_get_product_lifetime_returns_exception() throws Exception {
        given(factSetSecurity.getToken()).willReturn("Bearer token");
        given(httpClient.send(any(HttpRequest.class),any(HttpResponse.BodyHandler.class))).willThrow(new IOException());

        Assertions.assertThrows(NetworkException.class, () ->
                factSetClientImpl.getLifetimeReturns("MorningstarId"));
    }

    @Test
    public void should_get_product_lifetime_returns_serialize_exception() throws Exception {
        var file = ResourceUtils.getFile(SAMPLES_PATH + "lifetimeReturnsResponse.json");
        var json = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
        given(httpResponse.body()).willReturn(json);
        given(factSetSecurity.getToken()).willReturn("Bearer token");
        given(httpClient.send(any(HttpRequest.class),any(HttpResponse.BodyHandler.class))).willReturn(httpResponse);
        doThrow(new IndexOutOfBoundsException()).when(factSetConverter).convert(any(Class.class),anyList(), anyList());
        Assertions.assertThrows(RuntimeException.class, () ->
                factSetClientImpl.getLifetimeReturns("MorningstarId"));
    }

    @Test
    public void should_get_product_lifetime_returns() throws Exception {
        var file = ResourceUtils.getFile(SAMPLES_PATH + "lifetimeReturnsResponse.json");
        var json = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
        given(httpResponse.body()).willReturn(json);
        given(factSetSecurity.getToken()).willReturn("Bearer token");
        given(httpClient.send(any(HttpRequest.class),any(HttpResponse.BodyHandler.class))).willReturn(httpResponse);

        var result = factSetClientImpl.getLifetimeReturns("MorningstarId");
        Assertions.assertEquals( "11.8771547643241", result.getLifetimeMonthlyAnnualReturn());
    }
}
