package com.capgroup.digital.product.data.services.application.impl;

import com.capgroup.digital.product.data.services.data.morningstar.MorningstarClientImpl;
import com.capgroup.digital.product.data.services.data.morningstar.MorningstarSecurity;
import com.capgroup.digital.product.data.services.exception.DeserializationException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.StandardCharsets;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.doThrow;

@ExtendWith(MockitoExtension.class)
public class MorningstarClientImplTest {

    private static final String SAMPLES_PATH = "classpath:response/";

    @Mock
    private ResponseEntity responseEntity;
    @Mock
    private MorningstarSecurity morningstarSecurity;
    @Mock
    private RestTemplate restTemplate;
    @Spy
    private ObjectMapper objectMapper = new ObjectMapper();
    @InjectMocks
    private MorningstarClientImpl morningstarClientImpl;

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(morningstarClientImpl, "dailyReturnsUrl",
                "http://api.morningstar.com/v2/service/mf/DailyPerformance/mstarid/");
    }
    @Test
    public void should_get_daily_returns_exception () throws Exception {
        given(morningstarSecurity.getToken()).willReturn("accessCode");
        given(restTemplate.getForEntity(any(String.class),any(Class.class)))
                .willThrow(new RestClientException(""));
        Assertions.assertThrows(RuntimeException.class, () ->
                morningstarClientImpl.getDailyReturns("MorningstarId"));
    }

    @Test
    public void should_get_daily_returns_serialize_exception() throws Exception {
        var file = ResourceUtils.getFile(SAMPLES_PATH + "dailyPerformanceResponse.json");
        var json = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
        given(responseEntity.getBody()).willReturn(json);
        given(morningstarSecurity.getToken()).willReturn("accessCode");
        given(restTemplate.getForEntity(any(String.class),any(Class.class))).willReturn(responseEntity);
        doThrow(new JsonProcessingException(""){}).when(objectMapper).readValue(any(String.class), any(Class.class));
        Assertions.assertThrows(DeserializationException.class, () ->
                morningstarClientImpl.getDailyReturns("MorningstarId"));
    }

    @Test
    public void should_get_daily_returns() throws Exception {
        var file = ResourceUtils.getFile(SAMPLES_PATH + "dailyPerformanceResponse.json");
        var json = FileUtils.readFileToString(file, StandardCharsets.UTF_8);
        given(responseEntity.getBody()).willReturn(json);
        given(morningstarSecurity.getToken()).willReturn("accessCode");
        given(restTemplate.getForEntity(any(String.class),any(Class.class))).willReturn(responseEntity);

        var result = morningstarClientImpl.getDailyReturns("MorningstarId");
        Assertions.assertEquals("13.36995",result.getReturnYTD());
        Assertions.assertEquals("2021-07-08",result.getDayEndDate());
    }

}
