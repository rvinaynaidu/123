package com.capgroup.digital.product.data.services.application.impl;

import com.capgroup.digital.product.data.services.application.ReturnsServiceImpl;
import com.capgroup.digital.product.data.services.data.factset.FactSetClient;
import com.capgroup.digital.product.data.services.data.factset.dto.LifetimeReturnsDto;
import com.capgroup.digital.product.data.services.data.factset.dto.MetadataDto;
import com.capgroup.digital.product.data.services.data.factset.dto.StatisticsDto;
import com.capgroup.digital.product.data.services.data.factset.mapping.ProductReturnsMapper;
import com.capgroup.digital.product.data.services.data.morningstar.MorningstarClient;
import com.capgroup.digital.product.data.services.data.morningstar.dto.DailyPerformanceDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;

@ExtendWith(MockitoExtension.class)
public class ReturnsServiceImplTest {
    @Mock
    private FactSetClient factSetClient;
    @Mock
    private MorningstarClient morningstarClient;
    @Spy
    private ProductReturnsMapper productReturnsMapper = Mappers.getMapper(ProductReturnsMapper.class);
    @InjectMocks
    private ReturnsServiceImpl returnsServiceImpl;

    @Test
    public void should_get_returns_single() throws Exception {
        var metadataDto = new MetadataDto();
        metadataDto.setMorningstarName("American Funds AMCAP A");
        metadataDto.setTicker("AMCPX");
        metadataDto.setOneYearQuarterlyLoadAdjustedReturn("44.8659400939941");
        metadataDto.setThirtyDayYield(("0.0399999991059303"));
        var statisticsDto = new StatisticsDto();
        statisticsDto.setOneYearMonthlyAnnualizedReturnNav("34.7414129697894");
        statisticsDto.setThreeYearMonthlyAnnualizedReturnNav("15.5665128396448");
        var dailyReturnsDto = new DailyPerformanceDto();
        dailyReturnsDto.setReturnYTD("13.36995");
        dailyReturnsDto.setDayEndDate("2021-07-08");
        var lifetimeReturnsDto = new LifetimeReturnsDto();
        lifetimeReturnsDto.setLifetimeMonthlyAnnualReturn("11.8771547643241");

        given(factSetClient.getProductMetaData(anyString())).willReturn(metadataDto);
        given(factSetClient.getProductStatistics(anyString())).willReturn(statisticsDto);
        given(factSetClient.getLifetimeReturns(anyString())).willReturn(lifetimeReturnsDto);
        given(morningstarClient.getDailyReturns(anyString())).willReturn(dailyReturnsDto);

        var result = returnsServiceImpl.getReturns("FOUSA00B49");
        Assertions.assertEquals(new BigDecimal(metadataDto.getOneYearQuarterlyLoadAdjustedReturn()),
                result.getQuarterlyAnnualReturnsMop().getOneYearReturn());
        Assertions.assertEquals(new BigDecimal(statisticsDto.getOneYearMonthlyAnnualizedReturnNav()),
                result.getMonthlyAnnualReturnsNav().getOneYearReturn());
        Assertions.assertEquals(new BigDecimal(statisticsDto.getThreeYearMonthlyAnnualizedReturnNav()),
                result.getMonthlyAnnualReturnsNav().getThreeYearReturn());
        Assertions.assertEquals(new BigDecimal(metadataDto.getThirtyDayYield()),
                result.getSecYield().getThirtyDayYield());
        Assertions.assertEquals(new BigDecimal(dailyReturnsDto.getReturnYTD()),
                result.getDailyYtd().getYtdReturn());
        Assertions.assertEquals(LocalDate.parse(dailyReturnsDto.getDayEndDate(),
                DateTimeFormatter.ofPattern("yyyy-MM-dd")),
                result.getDailyYtd().getAsOfDate());
        Assertions.assertEquals(new BigDecimal(lifetimeReturnsDto.getLifetimeMonthlyAnnualReturn()),
                result.getMonthlyAnnualReturnsNav().getLifetimeReturn());
    }
}
