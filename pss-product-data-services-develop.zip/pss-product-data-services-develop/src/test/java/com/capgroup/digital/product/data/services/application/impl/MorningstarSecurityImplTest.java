package com.capgroup.digital.product.data.services.application.impl;

import com.capgroup.digital.product.data.services.data.morningstar.MorningstarSecurityImpl;
import com.capgroup.digital.product.data.services.exception.DeserializationException;
import com.capgroup.digital.product.data.services.exception.NetworkException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;

@ExtendWith(MockitoExtension.class)
public class MorningstarSecurityImplTest {
    @Mock
    private ResponseEntity responseEntity;
    @Mock
    private RestTemplate restTemplate;
    @InjectMocks
    private MorningstarSecurityImpl morningstarSecurityImpl;

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(morningstarSecurityImpl, "authenticationUrl",
                "https://www.dev.capitalgroup.com/api/morningstar-auth/morningstaraccess");
    }

    @Test
    public void should_get_token_network_exception() {
        given(restTemplate.getForEntity(any(String.class),any(Class.class)))
                .willThrow(new RestClientException(""));
        Assertions.assertThrows(RuntimeException.class, () ->
                morningstarSecurityImpl.getToken());
    }

    @Test
    public void should_get_token() throws NetworkException, DeserializationException {
        var accessCode = "{\"accessCode\":q8ah2j2bovb5w40xbaj5oc08pxrk4khh}";
        given(responseEntity.getBody()).willReturn(accessCode);
        given(restTemplate.getForEntity(any(String.class),any(Class.class))).willReturn(responseEntity);
        Assertions.assertEquals("q8ah2j2bovb5w40xbaj5oc08pxrk4khh",morningstarSecurityImpl.getToken());
    }
}
