package com.capgroup.digital.product.data.services.application.impl;

import com.capgroup.digital.product.data.services.data.factset.FactSetClient;
import com.capgroup.digital.product.data.services.data.factset.dto.MetadataDto;
import com.capgroup.digital.product.data.services.data.factset.mapping.ProductExpensesMapper;
import com.capgroup.digital.product.data.services.application.ExpensesServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;

@ExtendWith(MockitoExtension.class)
public class ExpensesServiceImplTest {
    @Mock
    private FactSetClient factSetClient;
    @Spy
    private ProductExpensesMapper productExpensesMapper= Mappers.getMapper(ProductExpensesMapper.class);
    @InjectMocks
    private ExpensesServiceImpl expensesServiceImpl;

    @Test
    public void should_get_expenses_single() throws Exception {
        var metadataDto = new MetadataDto();
        metadataDto.setMorningstarName("American Funds AMCAP A");
        metadataDto.setTicker("AMCPX");
        metadataDto.setNetExpenseRatio("0.680000007152557");
        metadataDto.setMaxFrontLoad("5.75");

        given(factSetClient.getProductMetaData(anyString())).willReturn(metadataDto);
        
        var result = expensesServiceImpl.getExpenseRatio("FOUSA00B49");
        Assertions.assertEquals(new BigDecimal(metadataDto.getNetExpenseRatio()), result.getNetExpenseRatio());
        Assertions.assertEquals(new BigDecimal(metadataDto.getMaxFrontLoad()), result.getMaxSalesCharge());
    }
}
