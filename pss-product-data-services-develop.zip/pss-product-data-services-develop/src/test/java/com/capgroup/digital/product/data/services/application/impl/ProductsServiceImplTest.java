package com.capgroup.digital.product.data.services.application.impl;

import com.capgroup.digital.product.data.services.application.ExpensesService;
import com.capgroup.digital.product.data.services.application.ProductDataService;
import com.capgroup.digital.product.data.services.application.ProductsServiceImpl;
import com.capgroup.digital.product.data.services.application.ReturnsService;
import com.capgroup.digital.product.data.services.data.dto.ProductData;
import com.capgroup.digital.product.data.services.data.dto.ProductExpenseRatio;
import com.capgroup.digital.product.data.services.data.dto.ProductReturns;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.ResourceUtils;

import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;

@ExtendWith(MockitoExtension.class)
public class ProductsServiceImplTest {

    private static final String SAMPLES_PATH = "classpath:response/";

    @Mock
    private ProductDataService productDataService;
    @Mock
    private ReturnsService returnsService;
    @Mock
    private ExpensesService expensesService;
    @InjectMocks
    private ProductsServiceImpl productsServiceImpl;

    @Test
    public void should_get_all_product_data() throws Exception {
        var productDataFile = ResourceUtils.getFile(SAMPLES_PATH + "productDataResponse.json");
        var productData = new ObjectMapper().readValue(productDataFile, ProductData.class);
        given(productDataService.getProductData(anyString())).willReturn(productData);

        var returnsFile = ResourceUtils.getFile(SAMPLES_PATH + "returnsResponse.json");
        var returns = new ObjectMapper().readValue(returnsFile, ProductReturns.class);
        given(returnsService.getReturns(anyString())).willReturn(returns);

        var expensesFile = ResourceUtils.getFile(SAMPLES_PATH + "expensesResponse.json");
        var expenses = new ObjectMapper().readValue(expensesFile, ProductExpenseRatio.class);
        given(expensesService.getExpenseRatio(anyString())).willReturn(expenses);

        var result = productsServiceImpl.getAllProductData(List.of("ids"));
        Assertions.assertEquals(productData.getMorningstarId(), result.get(0).getProductData().getMorningstarId());
        Assertions.assertEquals(productData.getName(), result.get(0).getProductData().getName());
        Assertions.assertEquals(returns.getQuarterlyAnnualReturnsMop().getOneYearReturn(),
                result.get(0).getReturns().getQuarterlyAnnualReturnsMop().getOneYearReturn());
        Assertions.assertEquals(returns.getQuarterlyAnnualReturnsMop().getThreeYearReturn(),
                result.get(0).getReturns().getQuarterlyAnnualReturnsMop().getThreeYearReturn());
        Assertions.assertEquals(expenses.getNetExpenseRatio(),
                result.get(0).getExpenseRatios().getNetExpenseRatio());
        Assertions.assertEquals(expenses.getGrossExpenseRatio(),
                result.get(0).getExpenseRatios().getGrossExpenseRatio());
    }
}
