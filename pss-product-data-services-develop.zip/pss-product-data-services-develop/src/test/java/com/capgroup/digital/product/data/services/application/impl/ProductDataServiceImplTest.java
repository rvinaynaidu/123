package com.capgroup.digital.product.data.services.application.impl;

import com.capgroup.digital.product.data.services.application.ProductDataServiceImpl;
import com.capgroup.digital.product.data.services.data.factset.FactSetClient;
import com.capgroup.digital.product.data.services.data.factset.dto.MetadataDto;
import com.capgroup.digital.product.data.services.data.factset.mapping.ProductDataMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;

@ExtendWith(MockitoExtension.class)
public class ProductDataServiceImplTest {
    @Mock
    private FactSetClient factSetClient;
    @Spy
    private ProductDataMapper productDataMapper = Mappers.getMapper(ProductDataMapper.class);
    @InjectMocks
    private ProductDataServiceImpl productDataServiceImpl;

    @Test
    public void should_get_basic_product_data() throws Exception {
        var metadataDto = new MetadataDto();
        metadataDto.setMorningstarId("FOUSA00B49");
        metadataDto.setTicker("AMCPX");
        metadataDto.setMorningstarName("American Funds AMCAP A");

        given(factSetClient.getProductMetaData(anyString())).willReturn(metadataDto);
        var result = productDataServiceImpl.getProductData("FOUSA00B49");
        Assertions.assertEquals(metadataDto.getMorningstarId(), result.getMorningstarId());
        Assertions.assertEquals(metadataDto.getTicker(), result.getTicker());
        Assertions.assertEquals(metadataDto.getMorningstarName(), result.getName());
    }
}
