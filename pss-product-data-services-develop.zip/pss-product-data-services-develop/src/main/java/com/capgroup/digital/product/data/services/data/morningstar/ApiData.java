package com.capgroup.digital.product.data.services.data.morningstar;

import com.capgroup.digital.product.data.services.data.morningstar.dto.DailyPerformanceDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApiData {
    @JsonProperty("api")
    private DailyPerformanceDto dailyPerformance;
}
