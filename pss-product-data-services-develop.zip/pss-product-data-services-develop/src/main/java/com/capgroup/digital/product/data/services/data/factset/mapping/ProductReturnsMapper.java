package com.capgroup.digital.product.data.services.data.factset.mapping;

import com.capgroup.digital.product.data.services.data.dto.*;
import com.capgroup.digital.product.data.services.data.factset.dto.LifetimeReturnsDto;
import com.capgroup.digital.product.data.services.data.factset.dto.MetadataDto;
import com.capgroup.digital.product.data.services.data.factset.dto.StatisticsDto;
import com.capgroup.digital.product.data.services.data.morningstar.dto.DailyPerformanceDto;
import org.mapstruct.*;
import org.springframework.stereotype.Service;

@Mapper(componentModel = "spring")
@Service
public interface ProductReturnsMapper {

    @Mappings({
            @Mapping(target = "monthlyAnnualReturnsNav", expression = "java(dtoToMonthlyAnnualReturnsNav(statisticsDto, lifetimeReturnsDto))"),
            @Mapping(target = "quarterlyAnnualReturnsMop", source = "metadataDto",
                    qualifiedByName = {"quarterly-annual-returns-mop"}),
            @Mapping(target = "monthlyAnnualReturnsMop", source = "metadataDto",
                    qualifiedByName = {"monthly-annual-returns-mop"}),
            @Mapping(target = "quarterlyAnnualReturnsNav", source = "metadataDto",
                    qualifiedByName = {"quarterly-annual-returns-nav"}),
            @Mapping(target = "secYield", source = "metadataDto",
                    qualifiedByName = {"sec-yield"}),
            @Mapping(target = "dailyYtd", source = "dailyPerformanceDto",
                    qualifiedByName = {"daily-ytd"})
    })
    ProductReturns dtoToProductReturns(MetadataDto metadataDto,
                                       StatisticsDto statisticsDto,
                                       DailyPerformanceDto dailyPerformanceDto,
                                       LifetimeReturnsDto lifetimeReturnsDto);

    @Mappings({
            @Mapping(target = "asOfDate", source = "statisticsDto.absoluteEndDate", dateFormat="yyyyMMdd"),
            @Mapping(target = "oneYearReturn", source = "statisticsDto.oneYearMonthlyAnnualizedReturnNav"),
            @Mapping(target = "threeYearReturn", source = "statisticsDto.threeYearMonthlyAnnualizedReturnNav"),
            @Mapping(target = "fiveYearReturn", source = "statisticsDto.fiveYearMonthlyAnnualizedReturnNav"),
            @Mapping(target = "tenYearReturn", source = "statisticsDto.tenYearMonthlyAnnualizedReturnNav"),
            @Mapping(target = "lifetimeReturn", source = "lifetimeReturnsDto.lifetimeMonthlyAnnualReturn")
    })
    @Named("monthly-annual-returns-nav")
    Returns dtoToMonthlyAnnualReturnsNav(StatisticsDto statisticsDto, LifetimeReturnsDto lifetimeReturnsDto);

    @Mappings({
            @Mapping(target = "asOfDate", source = "metadataDto.quarterEndDate", dateFormat="yyyyMMdd"),
            @Mapping(target = "oneYearReturn", source = "metadataDto.oneYearQuarterlyLoadAdjustedReturn"),
            @Mapping(target = "threeYearReturn", source = "metadataDto.threeYearQuarterlyLoadAdjustedReturn"),
            @Mapping(target = "fiveYearReturn", source = "metadataDto.fiveYearQuarterlyLoadAdjustedReturn"),
            @Mapping(target = "tenYearReturn", source = "metadataDto.tenYearQuarterlyLoadAdjustedReturn"),
            @Mapping(target = "lifetimeReturn", source = "metadataDto.lifetimeQuarterlyLoadAdjustedReturn"),
            @Mapping(target = "ytdReturn", source = "metadataDto.ytdLoadAdjustedReturn")
    })
    @Named("quarterly-annual-returns-mop")
    Returns dtoToQuarterlyAnnualReturnsMop(MetadataDto metadataDto);

    @Mappings({
            @Mapping(target = "asOfDate", source = "metadataDto.absoluteEndDate", dateFormat="yyyyMMdd"),
            @Mapping(target = "oneYearReturn", source = "metadataDto.oneYearMonthlyLoadAdjustedReturn"),
            @Mapping(target = "threeYearReturn", source = "metadataDto.threeYearMonthlyLoadAdjustedReturn"),
            @Mapping(target = "fiveYearReturn", source = "metadataDto.fiveYearMonthlyLoadAdjustedReturn"),
            @Mapping(target = "tenYearReturn", source = "metadataDto.tenYearMonthlyLoadAdjustedReturn"),
            @Mapping(target = "lifetimeReturn", source = "metadataDto.sinceInceptionMonthlyLoadAdjustedReturn"),
            @Mapping(target = "ytdReturn", source = "metadataDto.ytdMonthlyLoadAdjustedReturn")
    })
    @Named("monthly-annual-returns-mop")
    Returns dtoToMonthlyAnnualReturnsMop(MetadataDto metadataDto);

    @Mappings({
            @Mapping(target = "asOfDate", source = "metadataDto.quarterEndDate", dateFormat="yyyyMMdd"),
            @Mapping(target = "oneYearReturn", source = "metadataDto.oneYearQuarterly"),
            @Mapping(target = "threeYearReturn", source = "metadataDto.threeYearQuarterly"),
            @Mapping(target = "fiveYearReturn", source = "metadataDto.fiveYearQuarterly"),
            @Mapping(target = "tenYearReturn", source = "metadataDto.tenYearQuarterly")
    })
    @Named("quarterly-annual-returns-nav")
    Returns dtoToQuarterlyAnnualReturnsNav(MetadataDto metadataDto);

    @Mappings({
            @Mapping(target = "asOfDate", source = "metadataDto.absoluteEndDate", dateFormat="yyyyMMdd"),
            @Mapping(target = "secYieldAsOfDate", source = "metadataDto.secYieldAsOfDate", dateFormat="yyyyMMdd"),
            @Mapping(target = "thirtyDayYield", source = "metadataDto.thirtyDayYield"),
            @Mapping(target = "twelveMonthDistributionRates", source = "metadataDto.twelveMonthPortfolioAverageYield")
    })
    @Named("sec-yield")
    SecYield dtoToSecYield(MetadataDto metadataDto);

    @Mappings({
            @Mapping(target = "asOfDate", source = "dailyPerformanceDto.dayEndDate"),
            @Mapping(target = "ytdReturn", source = "dailyPerformanceDto.returnYTD")
    })
    @Named("daily-ytd")
    DailyReturn dtoDailyYtd(DailyPerformanceDto dailyPerformanceDto);
}
