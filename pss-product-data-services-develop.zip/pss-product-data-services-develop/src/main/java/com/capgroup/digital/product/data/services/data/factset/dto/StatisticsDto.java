package com.capgroup.digital.product.data.services.data.factset.dto;

import com.capgroup.digital.product.data.services.data.factset.annotation.FactSetHeader;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@Setter
public class StatisticsDto {
    @FactSetHeader("Annualized Return | 1 Year")
    private String oneYearMonthlyAnnualizedReturnNav;
    @FactSetHeader("Annualized Return | 3 Year")
    private String threeYearMonthlyAnnualizedReturnNav;
    @FactSetHeader("Annualized Return | 5 Year")
    private String fiveYearMonthlyAnnualizedReturnNav;
    @FactSetHeader("Annualized Return | 10 Year")
    private String tenYearMonthlyAnnualizedReturnNav;

    private String absoluteEndDate;
}
