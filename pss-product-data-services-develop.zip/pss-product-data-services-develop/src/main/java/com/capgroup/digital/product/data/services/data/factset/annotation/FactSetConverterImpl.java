package com.capgroup.digital.product.data.services.data.factset.annotation;

import com.capgroup.digital.product.data.services.exception.DeserializationException;
import com.capgroup.digital.product.data.services.constant.ErrorMessages;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

@Service
@NoArgsConstructor
@Slf4j
public class FactSetConverterImpl implements FactSetConverter {
    public Object convert(Class clazz, List<String> headerCells, List<String> values) {
        try {
            Class<?> objectClass = clazz;
            Object o = objectClass.getDeclaredConstructor().newInstance();
            for(Field field: objectClass.getDeclaredFields()) {
                field.setAccessible(true);
                if(field.isAnnotationPresent(FactSetHeader.class)) {
                    String headerName = getSerializedKey(field);
                    //Get index of headerCells
                    int index = headerCells.indexOf(headerName);
                    if(index >= 0) {
                        String value = values.get(index);
                        if(!value.equals("") && !value.equals("--") && !value.equals("NA")) {
                            field.set(o, value);
                        }
                    }
                }
                field.setAccessible(false);
            }
            return o;
        } catch (IllegalAccessException | NoSuchMethodException | InstantiationException | InvocationTargetException e) {
            log.error(ErrorMessages.FACTSET_SERIALIZE_ERROR, e);
            throw new DeserializationException(ErrorMessages.FACTSET_SERIALIZE_ERROR);
        }
    }

    private String getSerializedKey(Field field) {
        String annotationValue = field.getAnnotation(FactSetHeader.class).value();
        if (annotationValue.isEmpty()) {
            return field.getName();
        }
        else {
            return annotationValue;
        }
    }
}