package com.capgroup.digital.product.data.services.application;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.bohnman.squiggly.Squiggly;
import com.github.bohnman.squiggly.util.SquigglyUtils;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectionsServiceImpl implements ProjectionsService {
    public <T> List applyFilter(List<String> fields, List<T> data, Class clazz) {
        var filter = String.join(",", fields);
        var mapper = Squiggly.init(new ObjectMapper(), filter);
        return SquigglyUtils.listify(mapper, data, clazz);
    }
}
