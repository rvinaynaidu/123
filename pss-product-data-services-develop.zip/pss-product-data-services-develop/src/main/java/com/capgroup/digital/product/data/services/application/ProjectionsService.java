package com.capgroup.digital.product.data.services.application;

import java.util.List;

public interface ProjectionsService {
    <T> List applyFilter(List<String> fields, List<T> data, Class clazz);
}
