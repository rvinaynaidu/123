package com.capgroup.digital.product.data.services.data.factset.dto;

import com.capgroup.digital.product.data.services.data.factset.annotation.FactSetHeader;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@Setter
public class MetadataDto {
    @FactSetHeader("Morningstar Name")
    private String morningstarName;
    @FactSetHeader("Ticker")
    private String ticker;
    @FactSetHeader("Morningstar Investment Vehicle ID")
    private String morningstarId;
    @FactSetHeader("Morningstar Fund Objective")
    private String objective;
    @FactSetHeader("Morningstar Category")
    private String morningstarCategory;
    @FactSetHeader("Morningstar Fund Inception Date")
    private String fundInceptionDate;
    @FactSetHeader("Morningstar Oldest Share Class Inception Date")
    private String inceptionDate;
    @FactSetHeader("Prospectus net expense ratio (%)")
    private String netExpenseRatio;
    @FactSetHeader("Prospectus gross expense ratio (%)")
    private String grossExpenseRatio;
    @FactSetHeader("QE Load Adjusted Returns - 1 YR")
    private String oneYearQuarterlyLoadAdjustedReturn;
    @FactSetHeader("Load Adjusted Return - 3 Yr")
    private String threeYearQuarterlyLoadAdjustedReturn;
    @FactSetHeader("QE Load Adjusted Returns - 5 Yr")
    private String fiveYearQuarterlyLoadAdjustedReturn;
    @FactSetHeader("QE Load Adjusted Returns - 10 Yr")
    private String tenYearQuarterlyLoadAdjustedReturn;
    @FactSetHeader("QE Load Adjusted Return - Lifetime")
    private String lifetimeQuarterlyLoadAdjustedReturn;
    @FactSetHeader("Load Adjusted Returns - YTD")
    private String ytdLoadAdjustedReturn;
    @FactSetHeader("Latest Quarter End Date")
    private String quarterEndDate;
    @FactSetHeader("Max Front Load")
    private String maxFrontLoad;
    @FactSetHeader("12-month Portfolio Average Yield")
    private String twelveMonthPortfolioAverageYield;
    @FactSetHeader("QE Max Front Load")
    private String quarterlyMaxFrontLoad;
    @FactSetHeader("30 day SEC yield")
    private String thirtyDayYield;
    @FactSetHeader("QE 30 day SEC yield")
    private String quarterlyThirtyDayYield;
    @FactSetHeader("SEC Yield Date")
    private String secYieldAsOfDate;
    @FactSetHeader("12-month Portfolio Average Yield (tax equivalent)")
    private String twelveMonthPortfolioAverageYieldTaxEquivalent;
    @FactSetHeader("QE 1 Year Total Return")
    private String oneYearQuarterly;
    @FactSetHeader("QE 3 Year Total Return")
    private String threeYearQuarterly;
    @FactSetHeader("QE 5 Year Total Return")
    private String fiveYearQuarterly;
    @FactSetHeader("QE 10 Year Total Return")
    private String tenYearQuarterly;
    @FactSetHeader("ME Load Adjusted Returns - 1 Yr")
    private String oneYearMonthlyLoadAdjustedReturn;
    @FactSetHeader("ME Load Adjusted Returns - 3 Yr")
    private String threeYearMonthlyLoadAdjustedReturn;
    @FactSetHeader("ME Load Adjusted Returns - 5 Yr")
    private String fiveYearMonthlyLoadAdjustedReturn;
    @FactSetHeader("ME Load Adjusted Returns - 10 Yr")
    private String tenYearMonthlyLoadAdjustedReturn;
    @FactSetHeader("ME Load Adjusted Returns - SI")
    private String sinceInceptionMonthlyLoadAdjustedReturn;
    @FactSetHeader("ME Load Adjusted Returns - YTD")
    private String ytdMonthlyLoadAdjustedReturn;

    private String absoluteEndDate;
}
