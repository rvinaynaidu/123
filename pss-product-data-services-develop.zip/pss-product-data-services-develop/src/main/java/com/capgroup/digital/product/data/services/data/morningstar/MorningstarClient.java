package com.capgroup.digital.product.data.services.data.morningstar;

import com.capgroup.digital.product.data.services.data.morningstar.dto.DailyPerformanceDto;

public interface MorningstarClient {
    DailyPerformanceDto getDailyReturns(String morningstarId);
}
