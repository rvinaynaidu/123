package com.capgroup.digital.product.data.services.application;

import com.capgroup.digital.product.data.services.data.dto.ProductReturns;

public interface ReturnsService {
    ProductReturns getReturns(String morningstarId);
}