package com.capgroup.digital.product.data.services.exception;

public class FactSetKeyException extends RuntimeException {
    public FactSetKeyException(String errorMessage) {
        super(errorMessage);
    }
}
