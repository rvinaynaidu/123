package com.capgroup.digital.product.data.services.constant;

public class ErrorMessages {
    public static final String FACTSET_SERIALIZE_ERROR = "Error serializing FactSet response";
    public static final String DESERIALIZE_ERROR = "Error while deserializing response";
    public static final String NETWORK_REQUEST_ERROR = "Error while performing network request";
}
