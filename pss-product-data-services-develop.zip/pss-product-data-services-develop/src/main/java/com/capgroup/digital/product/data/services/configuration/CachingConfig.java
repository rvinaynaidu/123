package com.capgroup.digital.product.data.services.configuration;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@Configuration
@EnableCaching
@EnableScheduling
@Slf4j
public class CachingConfig {
    //Expiry is 14 minutes
    private static final int AUTH_TOKEN_TTL_MILLIS = 14*60*1000;
    private static final String FACTSET_ACCESS_TOKEN_CACHE_NAME = "factset-access-token";
    //Expiry is 59 minutes
    private static final int MORNINGSTAR_AUTH_TOKEN_TTL_MILLIS = 59*60*1000;
    private static final String MORNINGSTAR_ACCESS_TOKEN_CACHE_NAME = "morningstar-access-token";
    private CacheManager cacheManager;

    public CachingConfig(CacheManager cacheManager) {
        this.cacheManager = cacheManager;
    }

    @Scheduled(fixedRate = AUTH_TOKEN_TTL_MILLIS)
    public void clearFactSetAuthTokenCache() {
        log.debug("Clearing FactSet access token cache");
        cacheManager.getCache(FACTSET_ACCESS_TOKEN_CACHE_NAME).clear();
    }

    @Scheduled(fixedRate = MORNINGSTAR_AUTH_TOKEN_TTL_MILLIS)
    public void clearMorningstarAuthTokenCache() {
        log.debug("Clearing Morningstar access token cache");
        cacheManager.getCache(MORNINGSTAR_ACCESS_TOKEN_CACHE_NAME).clear();
    }
}
