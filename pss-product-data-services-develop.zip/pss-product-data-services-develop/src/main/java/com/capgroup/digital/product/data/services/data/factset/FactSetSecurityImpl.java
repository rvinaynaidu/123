package com.capgroup.digital.product.data.services.data.factset;

import com.capgroup.digital.product.data.services.constant.ErrorMessages;
import com.capgroup.digital.product.data.services.exception.DeserializationException;
import com.capgroup.digital.product.data.services.exception.FactSetKeyException;
import com.capgroup.digital.product.data.services.exception.NetworkException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class FactSetSecurityImpl implements FactSetSecurity {
    @Value("${factset.client.id}")
    private String clientId;
    @Value("${factset.key.id}")
    private String keyId;
    @Value("${factset.private.key}")
    private String privateKey;
    @Value("${factset.authentication.token.url}")
    private String tokenEndpoint;
    @Value("${factset.authentication.base.url}")
    private String authBaseUrl;
    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;

    public FactSetSecurityImpl(ObjectMapper objectMapper, HttpClient httpClient) {
        this.objectMapper = objectMapper;
        this.httpClient = httpClient;
    }

    @Cacheable(value="factset-access-token",sync=true)
    public String getToken() {
        byte[] encodedKey = Base64.decodeBase64(privateKey);
        var keySpec = new PKCS8EncodedKeySpec(encodedKey);
        KeyFactory kf = null;
        PrivateKey privKey = null;
        try {
            kf = KeyFactory.getInstance("RSA");
            privKey = kf.generatePrivate(keySpec);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            log.error("Could not create JWS", e);
            throw new FactSetKeyException(("Could not create JWS"));
        }
        String jws = Jwts.builder()
                .setSubject(clientId)
                .setIssuer(clientId)
                .setAudience(authBaseUrl)
                .setHeader(Map.of("kid", keyId, "alg", "RS256"))
                .setIssuedAt(Date.from(Instant.now()))
                .setExpiration(Date.from(Instant.now().plus(5, ChronoUnit.MINUTES)))
                .setNotBefore(Date.from(Instant.now().minus(5, ChronoUnit.MINUTES)))
                .setId(UUID.randomUUID().toString())
                .signWith(privKey, SignatureAlgorithm.RS256)
                .compact();
        Map<String, String> bodyParams = new HashMap<>();
        bodyParams.put("grant_type", "client_credentials");
        bodyParams.put("client_assertion_type", "urn:ietf:params:oauth:client-assertion-type:jwt-bearer");
        bodyParams.put("client_assertion", jws);

        String requestBody = bodyParams.keySet().stream()
                .map(key -> key + "=" + URLEncoder.encode(bodyParams.get(key), StandardCharsets.UTF_8))
                .collect(Collectors.joining("&"));

        var uri = UriComponentsBuilder
                .fromUriString(tokenEndpoint)
                .toUriString();

        var request = HttpRequest.newBuilder()
                .uri(URI.create(uri))
                .headers("Content-type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();
        HttpResponse<String> result = null;
        try {
            result = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (IOException | InterruptedException e) {
            log.error(ErrorMessages.NETWORK_REQUEST_ERROR, e);
            throw new NetworkException(ErrorMessages.NETWORK_REQUEST_ERROR);
        }
        AuthenticationResponse response = null;
        try {
            response = objectMapper.readValue(result.body(), AuthenticationResponse.class);
        } catch (JsonProcessingException e) {
            log.error(ErrorMessages.DESERIALIZE_ERROR, e);
            throw new DeserializationException(ErrorMessages.DESERIALIZE_ERROR);
        }
        log.info("Request successfully retrieved FactSet access token");
        return response.getAccessToken();
    }
}
