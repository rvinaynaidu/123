package com.capgroup.digital.product.data.services.data.factset.mapping;

import com.capgroup.digital.product.data.services.data.factset.dto.MetadataDto;
import com.capgroup.digital.product.data.services.data.dto.ProductData;
import com.capgroup.digital.product.data.services.data.dto.ProductExpenseRatio;
import org.mapstruct.*;
import org.springframework.stereotype.Service;

@Mapper(componentModel = "spring")
@Service
public interface ProductExpensesMapper {

    @Mappings({
            @Mapping(source = "metadataDto.absoluteEndDate", target = "asOfDate", dateFormat="yyyyMMdd"),
            @Mapping(source = "metadataDto.grossExpenseRatio", target = "grossExpenseRatio"),
            @Mapping(source = "metadataDto.netExpenseRatio", target = "netExpenseRatio"),
            @Mapping(source = "metadataDto.maxFrontLoad", target = "maxSalesCharge")
    })
    ProductExpenseRatio dtoToProductExpenseRatio(MetadataDto metadataDto);
}
