package com.capgroup.digital.product.data.services.application;

import com.capgroup.digital.product.data.services.data.dto.ProductExpenseRatio;

public interface ExpensesService {
    ProductExpenseRatio getExpenseRatio(String morningstarId);
}