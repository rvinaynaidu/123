package com.capgroup.digital.product.data.services.data.factset;

import com.capgroup.digital.product.data.services.data.factset.dto.LifetimeReturnsDto;
import com.capgroup.digital.product.data.services.data.factset.dto.MetadataDto;
import com.capgroup.digital.product.data.services.data.factset.dto.StatisticsDto;

public interface FactSetClient {
    MetadataDto getProductMetaData(String morningstarId);
    StatisticsDto getProductStatistics(String morningstarId);
    LifetimeReturnsDto getLifetimeReturns(String morningstarId);
}
