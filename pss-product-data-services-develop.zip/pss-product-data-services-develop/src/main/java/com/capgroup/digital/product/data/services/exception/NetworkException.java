package com.capgroup.digital.product.data.services.exception;

public class NetworkException extends RuntimeException {
    public NetworkException(String errorMessage) {
        super(errorMessage);
    }
}
