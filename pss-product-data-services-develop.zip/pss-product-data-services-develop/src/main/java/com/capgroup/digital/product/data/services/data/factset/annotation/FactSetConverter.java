package com.capgroup.digital.product.data.services.data.factset.annotation;

import com.capgroup.digital.product.data.services.exception.DeserializationException;

import java.util.List;

public interface FactSetConverter {
    Object convert(Class clazz, List<String> headerCells, List<String> values);
}
