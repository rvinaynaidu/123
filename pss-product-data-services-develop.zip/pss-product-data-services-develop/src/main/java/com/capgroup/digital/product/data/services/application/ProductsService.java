package com.capgroup.digital.product.data.services.application;

import com.capgroup.digital.product.data.services.data.dto.Product;

import java.util.List;

public interface ProductsService {
    List<Product> getAllProductData(List<String> morningstarIds);
}
