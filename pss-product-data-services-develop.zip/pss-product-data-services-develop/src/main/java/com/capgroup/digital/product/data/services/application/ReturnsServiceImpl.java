package com.capgroup.digital.product.data.services.application;

import com.capgroup.digital.product.data.services.data.dto.ProductReturns;
import com.capgroup.digital.product.data.services.data.factset.FactSetClient;
import com.capgroup.digital.product.data.services.data.morningstar.MorningstarClient;
import com.capgroup.digital.product.data.services.data.factset.mapping.ProductReturnsMapper;
import org.springframework.stereotype.Service;

@Service
public class ReturnsServiceImpl implements ReturnsService {
    private final FactSetClient factSetClient;
    private final ProductReturnsMapper productReturnsMapper;
    private final MorningstarClient morningstarClient;

    public ReturnsServiceImpl(FactSetClient factSetClient,
                              ProductReturnsMapper productReturnsMapper,
                              MorningstarClient morningstarClient) {
        this.factSetClient = factSetClient;
        this.productReturnsMapper = productReturnsMapper;
        this.morningstarClient = morningstarClient;
    }

    public ProductReturns getReturns(String morningstarId) {
        var metadataDto = factSetClient.getProductMetaData(morningstarId);
        var statsDto = factSetClient.getProductStatistics(morningstarId);
        var dailyReturnsDto = morningstarClient.getDailyReturns(morningstarId);
        var lifetimeReturnsDto = factSetClient.getLifetimeReturns(morningstarId);
        return productReturnsMapper.dtoToProductReturns(metadataDto, statsDto, dailyReturnsDto, lifetimeReturnsDto);
    }
}