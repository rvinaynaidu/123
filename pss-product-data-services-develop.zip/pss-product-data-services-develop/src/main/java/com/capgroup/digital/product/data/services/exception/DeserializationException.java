package com.capgroup.digital.product.data.services.exception;

public class DeserializationException extends RuntimeException {
    public DeserializationException(String errorMessage) {
        super(errorMessage);
    }
}
