package com.capgroup.digital.product.data.services.data.morningstar;

public interface MorningstarSecurity {
    String getToken();
}
