package com.capgroup.digital.product.data.services.data.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Product {
    private ProductData productData;
    private ProductReturns returns;
    private ProductExpenseRatio expenseRatios;
}