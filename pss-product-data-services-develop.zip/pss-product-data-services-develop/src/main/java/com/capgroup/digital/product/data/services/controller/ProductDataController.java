package com.capgroup.digital.product.data.services.controller;

import com.capgroup.digital.product.data.services.application.ExpensesService;
import com.capgroup.digital.product.data.services.application.ProductsService;
import com.capgroup.digital.product.data.services.application.ProjectionsService;
import com.capgroup.digital.product.data.services.application.ReturnsService;
import com.capgroup.digital.product.data.services.data.dto.Product;
import com.capgroup.digital.product.data.services.data.dto.ProductExpenseRatio;
import com.capgroup.digital.product.data.services.data.dto.ProductReturns;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@CrossOrigin
public class ProductDataController {

    private final ReturnsService returnsService;
    private final ExpensesService expensesService;
    private final ProductsService productsService;
    private final ProjectionsService projectionsService;

    public ProductDataController(ReturnsService returnsService,
                                 ExpensesService expensesService,
                                 ProductsService productsService,
                                 ProjectionsService projectionsService) {
        this.returnsService = returnsService;
        this.expensesService = expensesService;
        this.productsService = productsService;
        this.projectionsService = projectionsService;
    }

    @GetMapping(value="/products/{morningstarId}/returns")
    public ResponseEntity<ProductReturns> getReturnsByMorningstarId(@PathVariable String morningstarId) {
        log.info("Received request for returns with Morningstar Id "+morningstarId);
        var returns = returnsService.getReturns(morningstarId);
        return ResponseEntity.ok(returns);
    }

    @GetMapping(value="/products/{morningstarId}/expenses")
    public ResponseEntity<ProductExpenseRatio> getExpensesByMorningstarId(@PathVariable String morningstarId) {
        log.info("Received request for expense ratios with Morningstar Id "+morningstarId);
        var expenses = expensesService.getExpenseRatio(morningstarId);
        return ResponseEntity.ok(expenses);
    }

    @GetMapping(value="/products")
    public ResponseEntity<List<Product>> getProducts(@RequestParam(required = true) List<String> morningstarIds,
                                                     @RequestParam(required = false) List<String> fields) {
        log.info("Received request for multiple products "+String.join(",",morningstarIds));
        var products = productsService.getAllProductData(morningstarIds);
        if(fields == null || fields.isEmpty()){
            return new ResponseEntity<>(products, HttpStatus.OK);
        }
        var filteredProducts = projectionsService.applyFilter(fields, products, Product.class);
        return ResponseEntity.ok(filteredProducts);
    }
}