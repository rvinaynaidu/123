package com.capgroup.digital.product.data.services.application;

import com.capgroup.digital.product.data.services.data.dto.Product;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductsServiceImpl implements ProductsService {

    private final ReturnsService returnsService;
    private final ExpensesService expensesService;
    private final ProductDataService productDataService;

    public ProductsServiceImpl(ReturnsService returnsService,
                               ExpensesService expensesService,
                               ProductDataService productDataService) {
        this.returnsService = returnsService;
        this.expensesService = expensesService;
        this.productDataService = productDataService;
    }

    public List<Product> getAllProductData(List<String> morningstarIds) {
        List<Product> products = new ArrayList<>();
        for(String id: morningstarIds) {
            var product = new Product(productDataService.getProductData(id), returnsService.getReturns(id),
                    expensesService.getExpenseRatio(id));
            products.add(product);
        }
        return products;
    }
}
