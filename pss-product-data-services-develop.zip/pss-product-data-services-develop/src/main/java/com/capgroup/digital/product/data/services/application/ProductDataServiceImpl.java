package com.capgroup.digital.product.data.services.application;

import com.capgroup.digital.product.data.services.data.dto.ProductData;
import com.capgroup.digital.product.data.services.data.factset.FactSetClient;
import com.capgroup.digital.product.data.services.data.factset.mapping.ProductDataMapper;
import org.springframework.stereotype.Service;

@Service
public class ProductDataServiceImpl implements ProductDataService {
    private final FactSetClient factSetClient;
    private final ProductDataMapper productDataMapper;

    public ProductDataServiceImpl(FactSetClient factSetClient, ProductDataMapper productDataMapper) {
        this.factSetClient = factSetClient;
        this.productDataMapper = productDataMapper;
    }

    public ProductData getProductData(String morningstarId) {
        var metadataDto = factSetClient.getProductMetaData(morningstarId);
        return productDataMapper.dtoToProductData(metadataDto);
    }
}
