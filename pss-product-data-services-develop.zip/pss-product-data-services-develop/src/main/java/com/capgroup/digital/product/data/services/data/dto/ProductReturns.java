package com.capgroup.digital.product.data.services.data.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@Setter
public class ProductReturns {
    private Returns monthlyAnnualReturnsNav;
    private Returns monthlyCumulativeReturnsNav;
    private Returns monthlyAnnualReturnsMop;
    private Returns monthlyCumulativeReturnsMop;
    private Returns quarterlyAnnualReturnsNav;
    private Returns quarterlyCumulativeReturnsNav;
    private Returns quarterlyAnnualReturnsMop;
    private Returns quarterlyCumulativeReturnsMop;
    private DailyReturn dailyYtd;
    private SecYield secYield;
}