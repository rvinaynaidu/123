package com.capgroup.digital.product.data.services.data.factset;

import com.capgroup.digital.product.data.services.data.factset.annotation.FactSetConverter;
import com.capgroup.digital.product.data.services.data.factset.dto.LifetimeReturnsDto;
import com.capgroup.digital.product.data.services.data.factset.dto.MetadataDto;
import com.capgroup.digital.product.data.services.data.factset.dto.StatisticsDto;
import com.capgroup.digital.product.data.services.exception.DeserializationException;
import com.capgroup.digital.product.data.services.constant.ErrorMessages;
import com.capgroup.digital.product.data.services.exception.NetworkException;
import com.factset.protobuf.stach.extensions.RowStachExtensionBuilder;
import com.factset.protobuf.stach.extensions.StachExtensionFactory;
import com.factset.protobuf.stach.extensions.StachExtensions;
import com.factset.protobuf.stach.extensions.models.StachVersion;
import com.factset.protobuf.stach.extensions.models.TableData;
import com.google.protobuf.InvalidProtocolBufferException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

@Service
@Slf4j
public class FactSetClientImpl implements FactSetClient {
    @Value("${factset.metadata.url}")
    private String metadataUrl;

    @Value("${factset.stats.url}")
    private String statsUrl;

    @Value("${factset.lifetime-returns.url}")
    private String lifetimeReturnsUrl;

    private final FactSetSecurity factSetSecurity;
    private final FactSetConverter factSetConverter;
    private final HttpClient httpClient;

    private static final String ABSOLUTE_END_DATE = "Absolute End Date";

    public FactSetClientImpl(FactSetSecurity factSetSecurity,
                             FactSetConverter factSetConverter,
                             HttpClient httpClient) {
        this.factSetSecurity = factSetSecurity;
        this.factSetConverter = factSetConverter;
        this.httpClient = httpClient;
    }

    public MetadataDto getProductMetaData(String morningstarId) {
        var tableData = callFactSetApi(metadataUrl, morningstarId);
        var metadataDto = (MetadataDto) factSetConverter.convert(MetadataDto.class, getColumnIds(tableData), getColumnValues(tableData));

        //Get absolute end date from the metadata hash map
        if(tableData != null && !tableData.isEmpty() && tableData.get(0) != null
                && tableData.get(0).getMetadata() != null && tableData.get(0).getMetadata().containsKey(ABSOLUTE_END_DATE)) {
            metadataDto.setAbsoluteEndDate(tableData.get(0).getMetadata().get(ABSOLUTE_END_DATE));
        }
        return metadataDto;
    }

    public StatisticsDto getProductStatistics(String morningstarId) {
        var tableData = callFactSetApi(statsUrl, morningstarId);
        var statisticsDto = (StatisticsDto) factSetConverter.convert(StatisticsDto.class, getColumnIds(tableData), getColumnValues(tableData));

        //Get absolute end date from the metadata hash map
        if(tableData != null && !tableData.isEmpty() && tableData.get(0) != null
            && tableData.get(0).getMetadata() != null && tableData.get(0).getMetadata().containsKey(ABSOLUTE_END_DATE)) {
            statisticsDto.setAbsoluteEndDate(tableData.get(0).getMetadata().get(ABSOLUTE_END_DATE));
        }
        return statisticsDto;
    }

    public LifetimeReturnsDto getLifetimeReturns(String morningstarId) {
        var tableData = callFactSetApi(lifetimeReturnsUrl, morningstarId);
        var lifetimeReturnsDto = (LifetimeReturnsDto) factSetConverter.convert(LifetimeReturnsDto.class,
                getColumnIds(tableData), getColumnValues(tableData));

        //Get absolute end date from the metadata hash map
        if(tableData != null && !tableData.isEmpty() && tableData.get(0) != null
                && tableData.get(0).getMetadata() != null
                && tableData.get(0).getMetadata().containsKey(ABSOLUTE_END_DATE)) {
            lifetimeReturnsDto.setAbsoluteEndDate(tableData.get(0).getMetadata().get(ABSOLUTE_END_DATE));
        }
        return lifetimeReturnsDto;
    }

    public List<TableData> callFactSetApi(String baseUrl, String morningstarId) {
        var url = new StringBuilder(baseUrl);
        var bearerToken = new StringBuilder("Bearer ");
        url.append(morningstarId);
        String token = factSetSecurity.getToken();
        bearerToken.append(token);

        var request = HttpRequest.newBuilder().uri(URI.create(url.toString()))
                .header("Authorization", bearerToken.toString())
                .GET()
                .build();
        HttpResponse<String> result = null;
        try {
            result = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            log.info("Request sent to "+url);
        } catch (IOException | InterruptedException e) {
            log.error(ErrorMessages.NETWORK_REQUEST_ERROR, e);
            throw new NetworkException(ErrorMessages.NETWORK_REQUEST_ERROR);
        }

        // Stach v2 Row Organized format
        RowStachExtensionBuilder stachExtensionBuilder = StachExtensionFactory.getRowOrganizedBuilder(StachVersion.V2);
        StachExtensions stachExtension = null;  // data is the stach input in string or object format
        try {
            stachExtension = stachExtensionBuilder.setPackage(result.body()).build();
            return stachExtension.convertToTable();
        } catch (InvalidProtocolBufferException e) {
            log.error(ErrorMessages.DESERIALIZE_ERROR, e);
            throw new DeserializationException(ErrorMessages.NETWORK_REQUEST_ERROR);
        }
    }

    public List<String> getColumnIds(List<TableData> tableData) {
        return tableData.get(0).getRows().get(0).getCells();
    }
    public List<String> getColumnValues(List<TableData> tableData) {
        return tableData.get(0).getRows().get(1).getCells();
    }
}
