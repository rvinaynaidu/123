package com.capgroup.digital.product.data.services.data.factset.dto;

import com.capgroup.digital.product.data.services.data.factset.annotation.FactSetHeader;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@Setter
public class LifetimeReturnsDto {
    @FactSetHeader("Annualized Return | Lifetime")
    private String lifetimeMonthlyAnnualReturn;
    @FactSetHeader("Cumulative Return | Lifetime")
    private String lifeMonthlyCumulativeReturn;

    private String absoluteEndDate;
}
