package com.capgroup.digital.product.data.services.data.morningstar;

import com.capgroup.digital.product.data.services.constant.ErrorMessages;
import com.capgroup.digital.product.data.services.exception.DeserializationException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class MorningstarSecurityImpl implements MorningstarSecurity {
    @Value("${morningstar.auth.url}")
    private String authenticationUrl;

    private final RestTemplate restTemplate;

    public MorningstarSecurityImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Cacheable(value="morningstar-access-token",sync=true)
    public String getToken() {
        String token;
        /*
            RestTemplate is used because of the proxy authentication required by Morningstar.
         */
        log.info("Request sent to "+authenticationUrl);
        ResponseEntity<String> response = restTemplate.getForEntity(authenticationUrl, String.class);
        /*
            Gson is used because the response doesn't return the access code in quotes.
            Since it isn't a valid JSON, Jackson is unable to parse the response.
        */
        try {
            JsonObject json = JsonParser.parseString(response.getBody()).getAsJsonObject();
            token = json.get("accessCode").getAsString();
        } catch (JsonSyntaxException e) {
            log.error(ErrorMessages.DESERIALIZE_ERROR, e);
            throw new DeserializationException(ErrorMessages.NETWORK_REQUEST_ERROR);
        }
        log.info("Request successfully retrieved Morningstar access token");
        return token;
    }
}
