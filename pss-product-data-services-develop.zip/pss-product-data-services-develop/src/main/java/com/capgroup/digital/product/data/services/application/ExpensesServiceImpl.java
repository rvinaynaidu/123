package com.capgroup.digital.product.data.services.application;

import com.capgroup.digital.product.data.services.data.dto.ProductExpenseRatio;
import com.capgroup.digital.product.data.services.data.factset.FactSetClient;
import com.capgroup.digital.product.data.services.data.factset.mapping.ProductExpensesMapper;
import org.springframework.stereotype.Service;

@Service
public class ExpensesServiceImpl implements ExpensesService {
    private final FactSetClient factSetClient;
    private final ProductExpensesMapper productExpensesMapper;

    public ExpensesServiceImpl(FactSetClient factSetClient, ProductExpensesMapper productExpensesMapper) {
        this.factSetClient = factSetClient;
        this.productExpensesMapper = productExpensesMapper;
    }

    public ProductExpenseRatio getExpenseRatio(String morningstarId) {
        var metadataDto = factSetClient.getProductMetaData(morningstarId);
        return productExpensesMapper.dtoToProductExpenseRatio(metadataDto);
    }
}