package com.capgroup.digital.product.data.services.data.morningstar.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class DailyPerformanceDto {
    @JsonProperty("DayEndDate")
    private String dayEndDate;
    @JsonProperty("ReturnYTD")
    private String returnYTD;
}
