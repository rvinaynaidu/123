package com.capgroup.digital.product.data.services.application;

import com.capgroup.digital.product.data.services.data.dto.ProductData;

public interface ProductDataService {
    ProductData getProductData(String morningstarId);
}
