package com.capgroup.digital.product.data.services.data.factset.mapping;

import com.capgroup.digital.product.data.services.data.dto.ProductData;
import com.capgroup.digital.product.data.services.data.factset.dto.MetadataDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.springframework.stereotype.Service;

@Mapper(componentModel = "spring")
@Service
public interface ProductDataMapper {
    @Mappings({
            @Mapping(target = "morningstarId", source = "metadataDto.morningstarId"),
            @Mapping(target = "ticker", source = "metadataDto.ticker"),
            @Mapping(target = "name", source = "metadataDto.morningstarName"),
            @Mapping(target = "inceptionDate", source = "metadataDto.inceptionDate", dateFormat="yyyyMMdd"),
            @Mapping(target = "objective", source = "metadataDto.morningstarName"),
            @Mapping(target = "morningstarCategory", source = "metadataDto.morningstarCategory"),
    })
    @Named("product-data")
    ProductData dtoToProductData(MetadataDto metadataDto);
}
