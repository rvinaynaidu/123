package com.capgroup.digital.product.data.services.data.factset;

public interface FactSetSecurity {
    String getToken();
}
