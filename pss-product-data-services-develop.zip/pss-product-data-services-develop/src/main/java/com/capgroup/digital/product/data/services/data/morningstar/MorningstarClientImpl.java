package com.capgroup.digital.product.data.services.data.morningstar;

import com.capgroup.digital.product.data.services.constant.ErrorMessages;
import com.capgroup.digital.product.data.services.data.morningstar.dto.DailyPerformanceDto;
import com.capgroup.digital.product.data.services.exception.DeserializationException;
import com.capgroup.digital.product.data.services.exception.NetworkException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class MorningstarClientImpl implements MorningstarClient {
    @Value("${morningstar.daily-returns.url}")
    private String dailyReturnsUrl;

    private final MorningstarSecurity morningstarSecurity;
    private final ObjectMapper objectMapper;
    private final RestTemplate restTemplate;

    public MorningstarClientImpl(MorningstarSecurity morningstarSecurity, ObjectMapper objectMapper, RestTemplate restTemplate) {
        this.morningstarSecurity = morningstarSecurity;
        this.objectMapper = objectMapper;
        this.restTemplate = restTemplate;
    }

    public DailyPerformanceDto getDailyReturns(String morningstarId) throws NetworkException, DeserializationException {
        String token = morningstarSecurity.getToken();
        var url = new StringBuilder(dailyReturnsUrl);
        url.append(morningstarId).append("?accesscode=").append(token).append("&format=json");
        /*
            RestTemplate is used because of the proxy authentication required by Morningstar.
         */
        log.info("Request sent to "+url.toString());
        ResponseEntity<String> response = restTemplate.getForEntity(url.toString(), String.class);

        ApiResponse json = null;
        try {
            json = objectMapper.readValue(response.getBody(), ApiResponse.class);
        } catch (JsonProcessingException e) {
            log.error(ErrorMessages.DESERIALIZE_ERROR, e);
            throw new DeserializationException(ErrorMessages.NETWORK_REQUEST_ERROR);
        }
        return json.getData().getDailyPerformance();
    }
}
