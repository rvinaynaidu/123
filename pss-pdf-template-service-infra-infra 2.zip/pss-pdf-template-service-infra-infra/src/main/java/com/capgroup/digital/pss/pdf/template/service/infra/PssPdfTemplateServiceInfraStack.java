package com.capgroup.digital.pss.pdf.template.service.infra;

import java.util.logging.Logger;

import org.json.simple.JSONObject;

import software.amazon.awscdk.core.App;

public class PssPdfTemplateServiceInfraStack {
	
	private static final Logger LOGGER = Logger.getLogger(PssPdfTemplateServiceInfraStack.class.getName());



	public PssPdfTemplateServiceInfraStack(App app,String stackSuffix, JSONObject environment) {

		

		try {
			 new DbStack(app, "DatabaseStack" + stackSuffix, environment);
		     new EcsClusterStack(app, "EcsFargateClusterStack" + stackSuffix, environment);
		     new EcsServicesStack(app, "EcsFargateServicesStack" + stackSuffix, environment);
		     new CodePipelineStack(app, "CodePipelineStack" + stackSuffix, environment);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
     }
}
	

