package com.capgroup.digital.pss.pdf.template.service.infra.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SourceRepository {
    final String repoName;
    final String repoBranch;
    final String oauthTokenSecret;
    final String repoOwner;

    @JsonCreator
    public SourceRepository(
            @JsonProperty("repo_name") final String repoName,
            @JsonProperty("repo_branch") final String repoBranch,
            @JsonProperty("oauth_token_secret") final String oauthTokenSecret,
            @JsonProperty("repo_owner") final String repoOwner
    ) {
        this.repoName = repoName;
        this.repoBranch = repoBranch;
        this.oauthTokenSecret = oauthTokenSecret;
        this.repoOwner = repoOwner;
    }

    public String getRepoName() { return repoName; }

    public String getRepoBranch() { return repoBranch; }

    public String getOauthTokenSecret() { return oauthTokenSecret; }

    public String getRepoOwner() { return repoOwner; }

}
