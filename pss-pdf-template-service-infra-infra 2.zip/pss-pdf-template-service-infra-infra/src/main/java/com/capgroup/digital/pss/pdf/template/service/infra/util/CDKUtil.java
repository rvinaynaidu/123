package com.capgroup.digital.pss.pdf.template.service.infra.util;

import org.json.simple.JSONObject;
import software.amazon.awscdk.core.Construct;
import software.amazon.awscdk.core.IConstruct;
import software.amazon.awscdk.core.Tags;
import software.amazon.awscdk.services.ec2.*;
import software.amazon.awscdk.services.ecs.Cluster;
import software.amazon.awscdk.services.ecs.ClusterAttributes;
import software.amazon.awscdk.services.ecs.ICluster;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static com.capgroup.digital.pss.pdf.template.service.infra.util.Constants.AVAILABILITY_ZONE;
import static com.capgroup.digital.pss.pdf.template.service.infra.util.Constants.VPC_ID;
import static com.capgroup.digital.pss.pdf.template.service.infra.util.Messages.MISSING_CONSTRUCT_ID;
import static com.capgroup.digital.pss.pdf.template.service.infra.util.Messages.MISSING_CONSTRUCT_NAME;
import static com.google.common.base.Strings.isNullOrEmpty;

public class CDKUtil {
    private static final String ECS_SUBNET_GROUP = "ecs_subnet_group";
    private static final String IVPC_ID = "ImportedServiceVPC";
    private static final String ECS_SECURITY_GROUP = "ecs_security_group";
    private static final String ISECURITY_GROUP = "ImportedSecurityGroup";
    private static final String ECS_CLUSTER_NAME = "ecs_cluster_name";

    public static <T> T getConfigurationValue(final JSONObject jsonObject, final String configurationKey) {
        return (T) jsonObject.get(configurationKey);
    }

    public static IVpc getVpc(final Construct scope, final JSONObject environment) {

        final List<String> availabilityZones = getConfigurationValue(environment, AVAILABILITY_ZONE);

        final List<String> isolatedSubnets = getConfigurationValue(environment, ECS_SUBNET_GROUP);
        final String vpcId = getConfigurationValue(environment, VPC_ID);
        VpcAttributes byId = VpcAttributes.builder()
                .vpcId(vpcId)
                .availabilityZones(availabilityZones)
                .isolatedSubnetIds(isolatedSubnets)
                .build();

        IVpc vpc = Vpc.fromVpcAttributes(scope, IVPC_ID, byId);
        return vpc;
    }

    public static List<ISecurityGroup> getSecurityGroups(final Construct scope, final JSONObject environment) {
        final List<String> securityGroupIds = getConfigurationValue(environment, ECS_SECURITY_GROUP);
        final List<ISecurityGroup> securityGroups = new ArrayList<ISecurityGroup>();
        AtomicInteger i = new AtomicInteger(1);
        securityGroupIds.forEach(sgId -> {
            final ISecurityGroup sg = SecurityGroup.fromSecurityGroupId(
                    scope,
                    ISECURITY_GROUP + (i.getAndIncrement()),
                    sgId,
                    SecurityGroupImportOptions
                            .builder()
                            .mutable(false)
                            .allowAllOutbound(true)
                            .build()
            );

            securityGroups.add(sg);
        });
        return securityGroups;
    }

    public static ICluster getCluster(final Construct scope, final JSONObject environment, final IVpc vpc, final List<ISecurityGroup> securityGroups,
                                      final String serviceId) {
        final String clusterName = getConfigurationValue(environment, ECS_CLUSTER_NAME);

        return Cluster.fromClusterAttributes(scope, "cluster" + serviceId,
                ClusterAttributes.builder()
                        .clusterName(clusterName)
                        .vpc(vpc)
                        .securityGroups(securityGroups)
                        .build()
        );
    }

    public static void assignTags(final IConstruct construct, final Map<String, String> tags) {
        tags.keySet().forEach(tagName -> {
            Tags.of(construct).add(tagName, tags.get(tagName));
        });
    }

    public static String createConstructId(final String id, final String suffix) {
       return createConstructAttribute(id, suffix, MISSING_CONSTRUCT_ID);
    }

    public static String createConstructName(final String name, final String suffix) {
        return createConstructAttribute(name, suffix, MISSING_CONSTRUCT_NAME);
    }

    public static String createConstructAttribute(final String attribute, final String suffix, final String message) {
        if (isNullOrEmpty(attribute)) {
            throw new IllegalArgumentException(message);
        }

        return attribute + (isNullOrEmpty(suffix) ? "" : suffix);
    }
}
