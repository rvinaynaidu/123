package com.capgroup.digital.pss.pdf.template.service.infra.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.ImmutableList;

import java.util.List;

public class LbListener {
    final String id;
    final String listenerArn;
    final String securityGroup;
    final String pathPattern;
    final List<String> hostHeaders;
    final Integer listenerPriority;

    @JsonCreator
    public LbListener(
            @JsonProperty("id") final String id,
            @JsonProperty("cdk_wpc1_ext_listener_arn") final String listenerArn,
            @JsonProperty("cdk_web_sg") final String securityGroup,
            @JsonProperty("path_pattern") final String pathPattern,
            @JsonProperty("host_headers") final List<String> hostHeaders,
            @JsonProperty("listener_priority") final Integer listenerPriority
    ) {
        this.id = id;
        this.listenerArn = listenerArn;
        this.securityGroup = securityGroup;
        this.pathPattern = pathPattern;
        this.hostHeaders = ImmutableList.copyOf(hostHeaders);
        this.listenerPriority = listenerPriority;
    }

    public String getId() { return id; }

    public String getListenerArn() { return listenerArn; }

    public String getSecurityGroup() { return securityGroup; }

    public String getPathPattern() { return pathPattern; }

    public List<String> getHostHeaders() { return hostHeaders; }

    public Integer getListenerPriority() { return listenerPriority; }
}
