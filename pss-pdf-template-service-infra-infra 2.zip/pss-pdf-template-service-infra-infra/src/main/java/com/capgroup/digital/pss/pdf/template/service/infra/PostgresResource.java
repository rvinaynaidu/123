package com.capgroup.digital.pss.pdf.template.service.infra;


import org.jetbrains.annotations.NotNull;
import org.json.simple.JSONObject;
import software.amazon.awscdk.core.*;
import software.amazon.awscdk.services.ec2.*;
import software.amazon.awscdk.services.kms.Key;
import software.amazon.awscdk.services.rds.InstanceProps;
import software.amazon.awscdk.services.rds.*;
import software.amazon.awscdk.services.secretsmanager.Secret;
import software.amazon.awscdk.services.secretsmanager.SecretAttributes;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static com.capgroup.digital.pss.pdf.template.service.infra.util.CDKUtil.getConfigurationValue;

import static com.capgroup.digital.pss.pdf.template.service.infra.util.Constants.*;
import static com.capgroup.digital.pss.pdf.template.service.infra.util.Messages.*;
import static com.google.common.base.Strings.isNullOrEmpty;

public class PostgresResource {

  private static final String POSTGRES_FULL_VERSION = "postgres_full_version";
  private static final String POSTGRES_MAJOR_VERSION = "postgres_major_version";
  private static final String SUBNET_GROUP = "db_subnet_group";
  private static final String DATABASE_CLUSTER_IDENTIFIER = "db_cluster_id";
  private static final String DB_NAME = "db_name";
  private static final String DB_MASTER_USER_NAME = "db_master_user_name";
  private static final String DB_PORT_NUMBER = "db_port_number";
  private static final String IVPC_ID = "ImportedVpc";
  private static final String ISECURITY_GROUP = "ImportedRDSSecurityGroup";
  private static final String DB_INSTANCE_CLASS = "db_instance_class";
  private static final String DB_INSTANCE_SIZE = "db_instance_size";
  private static final String SECURITY_GROUP = "db_security_group";
  private static final String DB_CLUSTER_DELETION_PROTECTION = "db_cluster_deletion_protection";
  private static final String DB_KEY_ARN = "db_kms_key_arn";
  private static final String DB_RETENTION_DAYS = "db_retention_days";

  public PostgresResource(final Construct scope, JSONObject environment) throws Exception {

    if (scope == null || scope.getNode() == null) {
      throw new IllegalArgumentException(MISSING_REQUIRED_CONSTRUCT);
    }

    if (environment == null) {
      throw new IllegalArgumentException(MISSING_CDK_JSON_DATA);
    }

    final Map<String, String> tags = getConfigurationValue(environment, TAGS);

    final String postgresFullVersion = getConfigurationValue(environment, POSTGRES_FULL_VERSION);
    final String postgresMajorVersion = getConfigurationValue(environment, POSTGRES_MAJOR_VERSION);

    if (isNullOrEmpty(postgresFullVersion) || isNullOrEmpty(postgresMajorVersion)) {
      throw new Exception(MISSING_DB_VERSION);
    }
    final PostgresInstanceEngineProps pgProps = PostgresInstanceEngineProps.builder()
            .version(PostgresEngineVersion.of(postgresFullVersion, postgresMajorVersion))
            .build();

    final SubnetSelection subnetSelection = SubnetSelection.builder()
            .subnetType(SubnetType.ISOLATED)
            .build();

    final List<String> availabilityZones = getConfigurationValue(environment, AVAILABILITY_ZONE);

    final List<String> isolatedSubnets = getConfigurationValue(environment, SUBNET_GROUP);

    final String vpcId = getConfigurationValue(environment, VPC_ID);
    VpcAttributes byId = VpcAttributes.builder()
            .vpcId(vpcId)
            .availabilityZones(availabilityZones)
            .isolatedSubnetIds(isolatedSubnets)
            .build();

    IVpc vpc = Vpc.fromVpcAttributes(scope, IVPC_ID, byId);

    final List<String> securityGroupIds = getConfigurationValue(environment, SECURITY_GROUP);
    final List<ISecurityGroup> securityGroups = new ArrayList<ISecurityGroup>();
    AtomicInteger i = new AtomicInteger(1);
    securityGroupIds.forEach(sgId -> {

      /*final SecurityGroupProps sgProps = SecurityGroupProps.builder()
              .allowAllOutbound(false)
              .securityGroupName(sgName)
              .vpc(vpc)
              .build();
      securityGroups.add(new SecurityGroup(scope, "POSecurityGroup." +  sgName, sgProps));*/
      securityGroups.add(SecurityGroup.fromSecurityGroupId(scope, ISECURITY_GROUP+(i.getAndIncrement()), sgId));
    });

    final String dbName = getConfigurationValue(environment, DB_NAME);
    final String dbMasterUserName = getConfigurationValue(environment, DB_MASTER_USER_NAME);
    final Long dbPortNumber = getConfigurationValue(environment, DB_PORT_NUMBER);
    final String instanceClass = getConfigurationValue(environment, DB_INSTANCE_CLASS);
    final String instanceSize = getConfigurationValue(environment, DB_INSTANCE_SIZE);
    final String dbClusterId = getConfigurationValue(environment, DATABASE_CLUSTER_IDENTIFIER);
    final boolean dbClusterDeletionProtection =
            Boolean.toString(true).equals(getConfigurationValue(environment, DB_CLUSTER_DELETION_PROTECTION)) ? true : false;
    final Number dbRetentionDays = getConfigurationValue(environment, DB_RETENTION_DAYS);

    final AuroraPostgresClusterEngineProps clusterProps = AuroraPostgresClusterEngineProps.builder()
            .version(AuroraPostgresEngineVersion.of(postgresFullVersion, postgresMajorVersion))
            .build();

    final InstanceProps instanceProps = InstanceProps.builder()
            .instanceType(InstanceType.of(InstanceClass.valueOf(instanceClass), InstanceSize.valueOf(instanceSize)))
            .vpc(vpc)
            .vpcSubnets(subnetSelection)
            .securityGroups(securityGroups)
            .build();

    final Credentials login = Credentials.fromGeneratedSecret(dbMasterUserName);

    // backup props
    final BackupProps backupProps = BackupProps.builder()
            .retention(Duration.days(dbRetentionDays))
            .build();

    @NotNull final String keyArn = getConfigurationValue(environment, DB_KEY_ARN);;
    final DatabaseCluster databaseCluster = DatabaseCluster.Builder.create(scope, "poDBCluster")
            .clusterIdentifier(dbClusterId)
            .defaultDatabaseName(dbName)
            .deletionProtection(dbClusterDeletionProtection)
            .engine(DatabaseClusterEngine.auroraPostgres(clusterProps))
            .instances(2)
            .instanceProps(instanceProps)
            .credentials(login)
            .defaultDatabaseName(dbName)
            .port(dbPortNumber)
            .storageEncrypted(true)
            .storageEncryptionKey(Key.fromKeyArn(scope, "PoDBKey", keyArn))
            .backup(backupProps)
            .build();

    tags.keySet().forEach(tagName -> {
      Tags.of(databaseCluster).add(tagName, tags.get(tagName));
    });

    /*
    final DatabaseInstance databaseInstance = DatabaseInstance.Builder.create(scope, dbId)
            .engine(DatabaseInstanceEngine.postgres(pgProps))
            .instanceType(InstanceType.of(InstanceClass.valueOf(instanceClass), InstanceSize.valueOf(instanceSize)))
            .instanceIdentifier(dbId)
            .vpc(vpc)
            .vpcSubnets(subnetSelection)
            .securityGroups(securityGroups)
            .databaseName(dbName)
            .masterUsername(dbMasterUserName)
            .port(dbPortNumber)
            .build();*/
  }

  private SecretValue getSecret(final Construct scope, final String secretArnName) {

    final SecretValue secretValue = Secret.fromSecretAttributes(scope, "ImportedSecret", SecretAttributes.builder()
            .secretArn(secretArnName)
            .build()).getSecretValue();

    return secretValue;

  }
}
