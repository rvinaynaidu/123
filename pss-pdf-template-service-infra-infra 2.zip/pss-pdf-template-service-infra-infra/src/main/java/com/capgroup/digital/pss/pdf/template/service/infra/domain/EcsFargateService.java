package com.capgroup.digital.pss.pdf.template.service.infra.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;

import java.util.List;
import java.util.Map;

public class EcsFargateService {
    final String id;
    final String serviceName;
    final Integer memory;
    final Integer cpu;
    final String containerName;
    final String imageName;
    final SourceRepository sourceRepo;
    final String deployImageFile;
    final String artifactBucket;
    final Map<String, String> containerEnvVars;
    final Map<String, String> containerSecretsString;
    final String containerLogPrefix;
    final Integer containerPort;
    final Integer hostPort;
    final Integer desiredCount;
    final String healthCode;
    final String healthPath;
    final String healthPort;
    final List<LbListener> lbListeners;

    @JsonCreator
    public EcsFargateService(
            @JsonProperty("id") final String id,
            @JsonProperty("name") final String serviceName,
            @JsonProperty("memory") final Integer memory,
            @JsonProperty("cpu") final Integer cpu,
            @JsonProperty("ecs_container_name") final String containerName,
            @JsonProperty("ecs_image_name") final String imageName,
            @JsonProperty("source_repo") final SourceRepository sourceRepo,
            @JsonProperty("deploy_image_file") final String deployImageFile,
            @JsonProperty("artifact_bucket") final String artifactBucket,
            @JsonProperty("ecs_container_environment") final Map<String, String> containerEnvVars,
            @JsonProperty("ecs_container_secrets") final Map<String, String> containerSecretsString,
            @JsonProperty("ecs_container_log_prefix") final String containerLogPrefix,
            @JsonProperty("ecs_container_port") final Integer containerPort,
            @JsonProperty("ecs_host_port") final Integer hostPort,
            @JsonProperty("ecs_service_desired_count") final Integer desiredCount,
            @JsonProperty("cdk_health_code") final String healthCode,
            @JsonProperty("cdk_health_path") final String healthPath,
            @JsonProperty("cdk_heath_port") final String healthPort,
            @JsonProperty("lb_listeners") final List<LbListener> lbListeners
    ) {
        this.id = id;
        this.serviceName = serviceName;
        this.memory = memory;
        this.cpu = cpu;
        this.containerName = containerName;
        this.imageName = imageName;
        this.sourceRepo = sourceRepo;
        this.deployImageFile = deployImageFile;
        this.artifactBucket = artifactBucket;
        this.containerEnvVars = ImmutableMap.copyOf(containerEnvVars);
        this.containerSecretsString = ImmutableMap.copyOf(containerSecretsString);
        this.containerLogPrefix = containerLogPrefix;
        this.containerPort = containerPort;
        this.hostPort = hostPort;
        this.desiredCount = desiredCount;
        this.healthCode = healthCode;
        this.healthPath = healthPath;
        this.healthPort = healthPort;
        this.lbListeners = ImmutableList.copyOf(lbListeners);
    }

    public String getId() { return id; }

    public String getServiceName() { return serviceName; }

    public Integer getMemory() { return memory; }

    public Integer getCpu() { return cpu; }

    public String getContainerName() { return containerName; }

    public String getImageName() { return imageName; }

    public SourceRepository getSourceRepo() { return sourceRepo; }

    public String getDeployImageFile() { return deployImageFile; }

    public String getArtifactBucket() { return artifactBucket; }

    public Map<String, String> getContainerEnvVars() { return containerEnvVars; }

    public Map<String, String> getContainerSecretsString() { return containerSecretsString; }

    public String getContainerLogPrefix() { return containerLogPrefix; }

    public Integer getContainerPort() { return containerPort; }

    public Integer getHostPort() { return hostPort; }

    public Integer getDesiredCount() { return desiredCount; }

    public String getHealthCode() { return healthCode; }

    public String getHealthPath() { return healthPath; }

    public String getHealthPort() { return healthPort; }

    public List<LbListener> getLbListeners() { return lbListeners; }

}
