package com.capgroup.digital.pss.pdf.template.service.infra.util;

public class Constants {
    public static final String AVAILABILITY_ZONE= "availability_zone";
    public static final String VPC_ID = "vpc_id";
    public static final String TAGS = "tags";
    public static final String ENVIRONMENT = "environment";

    public static final String ADMIN_BOUNDARY_ARN = "admin-boundary-arn";
    public static final String REGION = "region";
}
