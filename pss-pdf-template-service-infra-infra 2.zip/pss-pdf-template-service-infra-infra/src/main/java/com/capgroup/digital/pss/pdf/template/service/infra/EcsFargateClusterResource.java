package com.capgroup.digital.pss.pdf.template.service.infra;

import org.json.simple.JSONObject;
import software.amazon.awscdk.core.Construct;
import software.amazon.awscdk.core.ConstructNode;
import software.amazon.awscdk.core.Tags;
import software.amazon.awscdk.services.ec2.*;
import software.amazon.awscdk.services.ecs.Cluster;

import java.util.List;
import java.util.Map;

import static com.capgroup.digital.pss.pdf.template.service.infra.util.CDKUtil.getConfigurationValue;
import static com.capgroup.digital.pss.pdf.template.service.infra.util.Constants.*;
import static com.capgroup.digital.pss.pdf.template.service.infra.util.Messages.MISSING_REQUIRED_CONSTRUCT;

public class EcsFargateClusterResource {

  private static final String ECS_SUBNET_GROUP = "ecs_subnet_group";
  private static final String ECS_CLUSTER_NAME = "ecs_cluster_name";
  private static final String CLUSTER_ID = "PoCluster";

  public EcsFargateClusterResource(final Construct scope, JSONObject environment) {

    if (scope == null || scope.getNode() == null) {
      throw new IllegalArgumentException(MISSING_REQUIRED_CONSTRUCT);
    }

    ConstructNode node = scope.getNode();

    final Map<String, String> tags = getConfigurationValue(environment, TAGS);

    final List<String> availabilityZones = getConfigurationValue(environment, AVAILABILITY_ZONE);

    final List<String> isolatedSubnets = getConfigurationValue(environment, ECS_SUBNET_GROUP);

    final String vpcId = getConfigurationValue(environment, VPC_ID);
    VpcAttributes byId = VpcAttributes.builder()
            .vpcId(vpcId)
            .availabilityZones(availabilityZones)
            .isolatedSubnetIds(isolatedSubnets)
            .build();

    IVpc vpc = Vpc.fromVpcAttributes(scope, "ImportedClusterVPC", byId);

    final String clusterName = getConfigurationValue(environment, ECS_CLUSTER_NAME);

    Cluster cluster = Cluster.Builder.create(scope, CLUSTER_ID)
            .vpc(vpc)
            .clusterName(clusterName)
            .build();

    tags.keySet().forEach(tagName -> {
      Tags.of(cluster).add(tagName, tags.get(tagName));
    });

  }

}
