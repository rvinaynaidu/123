package com.capgroup.digital.pss.pdf.template.service.infra.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.ImmutableMap;

import java.util.Map;

public class SubnetGroup {

    final String id;
    final String name;
    final String availabilityZone;
    final String routeTableId;

    @JsonCreator
    public SubnetGroup(
            @JsonProperty("subnet_id") final String id,
            @JsonProperty("name") final String name,
            @JsonProperty("availability_zone") final String availabilityZone,
            @JsonProperty("route_table_id") final String routeTableId

            ) {
        this.id = id;
        this.name = name;
        this.availabilityZone = availabilityZone;
        this.routeTableId = routeTableId;
    }

    public String getId() { return id; }

    public String getName() { return name; }

    public String getAvailabilityZone() { return availabilityZone; }

    public String getRouteTableId() { return routeTableId; }

}
