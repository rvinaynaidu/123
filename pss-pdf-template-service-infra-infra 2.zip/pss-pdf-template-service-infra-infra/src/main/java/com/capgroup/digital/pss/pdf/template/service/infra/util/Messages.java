package com.capgroup.digital.pss.pdf.template.service.infra.util;

public class Messages {

  public static final String MISSING_REQUIRED_CONSTRUCT = "Missing required scope construct!";
  public static final String MISSING_CDK_JSON_DATA = "Missing cdk json data!";
  public static final String MISSING_DB_VERSION = "Missing DB full or major version!";
  public static final String MISSING_CONSTRUCT_ID = "Missing Construct Id!";
  public static final String MISSING_CONSTRUCT_NAME = "Missing Construct Name!";
  public static final String UNSUPPORTED_ENVIRONMENT_FOR_CODEPIPELINE =
          "Unsupported environment for creation of CI/CD pipeline through application stack";

}
