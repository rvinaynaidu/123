package com.capgroup.digital.pss.pdf.template.service.infra;

import org.json.simple.JSONObject;
import software.amazon.awscdk.core.Construct;
import software.amazon.awscdk.core.Stack;
import software.amazon.awscdk.core.StackProps;

import java.io.IOException;

public class EcsServicesStack extends Stack {

  public EcsServicesStack(final Construct parent, final String id, JSONObject environment) throws IOException {
    this(parent, id, null, environment);
  }

  public EcsServicesStack(final Construct parent, final String id, final StackProps props, JSONObject environment) throws IOException {
    super(parent, id, props);

    new EcsFargateServicesResource(this, environment);
  }
}
