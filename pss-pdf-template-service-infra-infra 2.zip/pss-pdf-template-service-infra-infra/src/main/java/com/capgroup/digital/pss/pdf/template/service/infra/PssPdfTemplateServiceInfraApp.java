package com.capgroup.digital.pss.pdf.template.service.infra;

import static com.capgroup.digital.pss.pdf.template.service.infra.util.CDKUtil.getConfigurationValue;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import software.amazon.awscdk.core.App;

public class PssPdfTemplateServiceInfraApp {
	
	public static final String ENVIRONMENT_CONFIGURATION_KEY = "environment";
	public static final String STACK_SUFFIX_KEY = "stack_suffix";
	private static final ObjectMapper mapper = new ObjectMapper();
	private static final Logger LOG = Logger.getLogger(PssPdfTemplateServiceInfraApp.class.getName());
	
	static {
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}
	
	public static void main(final String[] args) throws FileNotFoundException, IOException, ParseException {


		App app = new App();
	    final JSONParser parser = new JSONParser();
	    final Object obj = parser.parse(new FileReader("cdk.json"));
	    final JSONObject jsonObject = (JSONObject) obj;

	    final JSONObject context = getConfigurationValue(jsonObject,"context");
	    final List<JSONObject> environments = getConfigurationValue(context, "environments");

	    for (JSONObject environment : environments) {
	      final String stackSuffix = getConfigurationValue(environment,"stack_suffix");
	      new PssPdfTemplateServiceInfraStack(app,stackSuffix,
					environment);
	    }
        
		
		
		app.synth();
	}


}
