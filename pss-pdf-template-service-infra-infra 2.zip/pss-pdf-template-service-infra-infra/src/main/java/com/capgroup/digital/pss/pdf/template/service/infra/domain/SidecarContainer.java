package com.capgroup.digital.pss.pdf.template.service.infra.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.ImmutableMap;

import java.util.Map;

public class SidecarContainer {
    final String id;
    final String imageName;
    final Map<String, String> containerEnvVars;
    final Map<String, String> containerSecretsString;
    final Integer port;

    @JsonCreator
    public SidecarContainer(
            @JsonProperty("id") final String id,
            @JsonProperty("image_name") final String imageName,
            @JsonProperty("environment") final Map<String, String> containerEnvVars,
            @JsonProperty("secrets") final Map<String, String> containerSecretsString,
            @JsonProperty("port") final Integer port

            ) {
        this.id = id;
        this.imageName = imageName;
        this.containerEnvVars = ImmutableMap.copyOf(containerEnvVars);
        this.containerSecretsString = ImmutableMap.copyOf(containerSecretsString);
        this.port = port;
    }

    public String getId() { return id; }

    public String getImageName() { return imageName; }

    public Map<String, String> getContainerEnvVars() { return containerEnvVars; }

    public Map<String, String> getContainerSecretsString() { return containerSecretsString; }

    public Integer getPort() { return port; }
}
