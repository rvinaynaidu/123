package com.capgroup.digital.pss.pdf.template.service.infra;

import com.capgroup.digital.pss.pdf.template.service.infra.domain.EcsFargateService;
import com.capgroup.digital.pss.pdf.template.service.infra.domain.LbListener;
import com.capgroup.digital.pss.pdf.template.service.infra.domain.SidecarContainer;
import com.capgroup.digital.pss.pdf.template.service.infra.domain.SubnetGroup;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;

import static com.capgroup.digital.pss.pdf.template.service.infra.util.CDKUtil.*;
import static com.capgroup.digital.pss.pdf.template.service.infra.util.Constants.*;
import static com.google.common.base.Strings.isNullOrEmpty;

import org.json.simple.JSONObject;
import software.amazon.awscdk.core.*;
import software.amazon.awscdk.services.ec2.*;
import software.amazon.awscdk.services.ecs.Protocol;
import software.amazon.awscdk.services.ecs.*;
import software.amazon.awscdk.services.elasticloadbalancingv2.HealthCheck;
import software.amazon.awscdk.services.elasticloadbalancingv2.*;
import software.amazon.awscdk.services.iam.*;
import software.amazon.awscdk.services.logs.LogGroup;
import software.amazon.awscdk.services.ssm.SecureStringParameterAttributes;
import software.amazon.awscdk.services.ssm.StringParameter;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static com.capgroup.digital.pss.pdf.template.service.infra.util.Messages.MISSING_REQUIRED_CONSTRUCT;
import static java.util.Collections.singletonList;
import static software.amazon.awscdk.services.elasticloadbalancingv2.Protocol.HTTPS;

public class EcsFargateServicesResource {

    private static final String ECS_SUBNET_GROUPS = "ecs_subnet_groups";
    private static final String ECS_SERVICES = "ecs_services";
    private static final String TARGET_GROUP_SUFFIX = "-tg";
    private static final String SSM_PREFIX = "ssm:";
    private static final String COLON_CHAR = ":";

    public EcsFargateServicesResource(final Construct scope, JSONObject environment) throws IOException {

    if (scope == null || scope.getNode() == null) {
      throw new IllegalArgumentException(MISSING_REQUIRED_CONSTRUCT);
    }

    final Map<String, String> tags = getConfigurationValue(environment, TAGS);

    final List<Map<String, String>> subnetGroupsConfiguration = getConfigurationValue(environment, ECS_SUBNET_GROUPS);

    final ObjectMapper mapper = new ObjectMapper();

    final String envName = getConfigurationValue(environment, ENVIRONMENT);

    final List<ISubnet> subnets = subnetGroupsConfiguration
            .stream()
            .map(map -> mapper.convertValue(map, SubnetGroup.class))
            .map(config -> {
              final SubnetAttributes attributes = SubnetAttributes
                      .builder()
                      .subnetId(config.getId())
                      .availabilityZone(config.getAvailabilityZone())
                      .routeTableId(config.getRouteTableId())
                      .build();
              return Subnet.fromSubnetAttributes(scope, config.getName(), attributes);
            })
            .collect(Collectors.toList());

    final SubnetSelection subnetSelection = SubnetSelection.builder()
            .subnets(subnets)
            .build();

    final IVpc vpc = getVpc(scope, environment);

    final List<ISecurityGroup> securityGroups = getSecurityGroups(scope, environment);

    /*
    Load the image tags
     */
    final String imageTagsString = FileUtils.readFileToString(new File("image.json"), StandardCharsets.UTF_8);
    final Map<String, String> imageTags = mapper.readValue(imageTagsString, Map.class);


    final Map<String, String>  sidecarStr = getConfigurationValue(environment, "sidecar");

    SidecarContainer sidecarContainer = mapper.convertValue(sidecarStr, new TypeReference<SidecarContainer>() {	});
    final String sidecarImageName = sidecarContainer.getImageName() + COLON_CHAR + imageTags.get("sidecar");
    final RepositoryImage sidecarRepositoryImage = ContainerImage.fromRegistry(sidecarImageName);

    final Map<String, Secret> sidecarSecrets = loadSecrets(scope, sidecarContainer.getId(), sidecarContainer.getContainerSecretsString());

    /*
      Sidecar Port Mapping
    */
    final PortMapping sidecarPortMapping = PortMapping.builder()
            .containerPort(sidecarContainer.getPort())
            .hostPort(sidecarContainer.getPort())
            .protocol(Protocol.TCP)
            .build();

    final List<String> servicesStr = getConfigurationValue(environment, ECS_SERVICES);

    List<EcsFargateService> services = mapper.convertValue(servicesStr, new TypeReference<List<EcsFargateService>>() {});

    services.forEach(service -> {

      final IRole taskRole = loadTaskRole(scope, service, tags, envName, environment);
      final String taskFamily = service.getServiceName();

      FargateTaskDefinition taskDefinition = FargateTaskDefinition.Builder.create(scope, "task" + service.getId())
              .executionRole(taskRole)
              .taskRole(taskRole)
              //.family(taskFamily)
              .memoryLimitMiB(service.getMemory())
              .cpu(service.getCpu())
              .build();

      tags.keySet().forEach(tagName -> {
        Tags.of(taskDefinition).add(tagName, tags.get(tagName));
      });

      final Map<String, Secret> containerSecrets = loadSecrets(scope, service.getId(), service.getContainerSecretsString());

      final String containerLogPrefix = service.getContainerLogPrefix();

      /*
      Log Group
     */
      final LogGroup serviceLogGroup = LogGroup.Builder.create(scope, "POServiceLogGroup" + service.getId())
              .logGroupName("/" + containerLogPrefix + "/" + service.getServiceName())
              .removalPolicy(RemovalPolicy.DESTROY)
              .build();

      final AwsLogDriverProps serviceLogDriverProps = AwsLogDriverProps.builder()
              .logGroup(serviceLogGroup)
              .streamPrefix(containerLogPrefix)
              .build();
      final LogDriver logDriver = LogDrivers.awsLogs(serviceLogDriverProps);

      final Map<String, String> sidecarEnvironment =
              getSSMEnvironmentValues(scope, sidecarContainer.getContainerEnvVars(), envName);

      /*
      Task Sidecar Container
      */
      final ContainerDefinitionProps sidecarDefinitionProps = ContainerDefinitionProps
              .builder()
              .image(sidecarRepositoryImage)
              .taskDefinition(taskDefinition)
              .environment(sidecarContainer.getContainerEnvVars())
              .secrets(sidecarSecrets)
              .logging(logDriver)
              .build();

      final ContainerDefinition sidecarContainerDefinition = taskDefinition.addContainer(
              "sidecarContainer" + service.getId(), sidecarDefinitionProps);

      sidecarContainerDefinition.addPortMappings(sidecarPortMapping);

      tags.keySet().forEach(tagName -> {
        Tags.of(sidecarContainerDefinition).add(tagName, tags.get(tagName));
      });

      final String serviceImageName = service.getImageName() + COLON_CHAR + imageTags.get("service" + service.getId());

      final ContainerDefinitionProps containerDefinitionProps = ContainerDefinitionProps.builder()
              .image(ContainerImage.fromRegistry(serviceImageName))
              .environment(service.getContainerEnvVars())
              .secrets(containerSecrets)
              .taskDefinition(taskDefinition)
              .logging(logDriver)
              .build();

      final ContainerDefinition containerDefinition = taskDefinition.addContainer(service.getContainerName(), containerDefinitionProps);

      tags.keySet().forEach(tagName -> {
        Tags.of(containerDefinition).add(tagName, tags.get(tagName));
      });

      final String ecsPlatformVersion = getConfigurationValue(environment, "ecs_platform_version");

      FargateService fargateService = FargateService.Builder.create(scope, "service" + service.getId())
              .cluster(getCluster(scope, environment, vpc, securityGroups, service.getId()))
              .taskDefinition(taskDefinition)
              .assignPublicIp(false)
              .serviceName(taskFamily)
              .platformVersion(FargatePlatformVersion.valueOf(ecsPlatformVersion))
              .securityGroups(securityGroups)
              .desiredCount(service.getDesiredCount())
              .vpcSubnets(subnetSelection)
              .build();

      tags.keySet().forEach(tagName -> {
        Tags.of(fargateService).add(tagName, tags.get(tagName));
      });

      final Number targetGroupPort = getConfigurationValue(environment, "ecs_target_group_port");

      final List<LbListener> lbListeners = service.getLbListeners();

      if (!lbListeners.isEmpty()) {
        lbListeners.forEach(lbListener -> {
          final ApplicationTargetGroup targetGroup = ApplicationTargetGroup.Builder.create(scope,
                  "targetGroup" + service.getId() + lbListener.getId())
                  .targetGroupName(service.getServiceName() + lbListener.getId() + TARGET_GROUP_SUFFIX)
                  .vpc(vpc)
                  .protocol(ApplicationProtocol.HTTPS)
                  .port(targetGroupPort)
                  .targetType(TargetType.IP)
                  .targets(singletonList(fargateService))
                  .build();

          tags.keySet().forEach(tagName -> {
            Tags.of(targetGroup).add(tagName, tags.get(tagName));
          });

          targetGroup.configureHealthCheck(HealthCheck.builder()
                  .healthyHttpCodes(service.getHealthCode())
                  .path(service.getHealthPath())
                  .port(service.getHealthPort())
                  .protocol(HTTPS)
                  .timeout(Duration.seconds(60))
                  .interval(Duration.seconds(120))
                  .build()
          );

          final ISecurityGroup listenerSg = SecurityGroup.fromSecurityGroupId(
                  scope,
                  "LBSecurityGroupId" + service.getId() + lbListener.getId(),
                  lbListener.getSecurityGroup(),
                  SecurityGroupImportOptions
                          .builder()
                          .mutable(false)
                          .allowAllOutbound(true)
                          .build()
          );

          final IApplicationListener applicationListener = ApplicationListener.fromApplicationListenerAttributes(scope,
                  "ImportedListener" + service.getId() + lbListener.getId(),
                  ApplicationListenerAttributes.builder()
                          .listenerArn(lbListener.getListenerArn())
                          //.defaultPort(lbDefaultPort)
                          .securityGroup(listenerSg)
                          .build());

          final List<ListenerCondition> listenerConditions = new ArrayList<>();
          if (!lbListener.getHostHeaders().isEmpty()) {
            listenerConditions.add(ListenerCondition.hostHeaders(lbListener.getHostHeaders()));
          }
          if (!isNullOrEmpty(lbListener.getPathPattern())) {
            listenerConditions.add(ListenerCondition.pathPatterns(singletonList(lbListener.getPathPattern())));
          }

          final ApplicationListenerRule applicationListenerRule = ApplicationListenerRule.Builder.create(scope,
                  "ListenerRule" + service.getId() + lbListener.getId())
                  .listener(applicationListener)
                  .targetGroups(singletonList(targetGroup))
                  .conditions(listenerConditions)
                  .priority(lbListener.getListenerPriority())
                  .build();

          tags.keySet().forEach(tagName -> {
              Tags.of(applicationListenerRule).add(tagName, tags.get(tagName));
          });
        });
      }
    });
  }

  private Map<String, Secret> loadSecrets(final Construct scope, final String id, final Map<String, String> containerSecretsString) {
    final Map<String, Secret> containerSecrets = Maps.newHashMap();

    AtomicInteger count = new AtomicInteger();
    containerSecretsString.keySet().forEach(secretKey -> {
      containerSecrets.put(secretKey,
              Secret.fromSsmParameter(
                      StringParameter.fromSecureStringParameterAttributes(scope, "StringParam" + id + (count.getAndIncrement()),
                              SecureStringParameterAttributes.builder()
                                      .parameterName(containerSecretsString.get(secretKey))
                                      .version(1)
                                      .build()
                      )
              )
      );
    });
    return containerSecrets;
  }

  private IRole loadTaskRole(final Construct scope, final EcsFargateService service, final Map<String, String> tags,
                             final String envName, JSONObject environment) {


      final String adminBoundaryArn = getConfigurationValue(environment, ADMIN_BOUNDARY_ARN);

      final String region = getConfigurationValue(environment, REGION);
      final IRole taskRole = Role.Builder.create(scope, "PoTaskRole" + service.getId())
              .description("Allows PO ECS tasks to call AWS services on your behalf.")
              .assumedBy(new ServicePrincipal("ecs-tasks.amazonaws.com"))
              .roleName("ecsTaskExecutionRole-" + service.getServiceName() + "-" + region)
              .permissionsBoundary(ManagedPolicy.fromManagedPolicyArn(scope, "adminBoundary" + service.getId(), adminBoundaryArn))
              .build();

      assignTags(taskRole, tags);

      final List<PolicyStatement> policyStatements = Arrays.asList(
              new PolicyStatement(PolicyStatementProps
                      .builder()
                      .actions(singletonList("ecr:*"))
                      .resources(singletonList("*"))
                      .build()
              ),
              new PolicyStatement(PolicyStatementProps
                      .builder()
                      .actions(Arrays.asList("ssm:Describe*", "ssm:List*", "ssm:Get*", "ssm:Put*"))
                      .resources(singletonList("arn:aws:ssm:*:*:parameter/" + envName +"/po/*"))
                      .build()
              ),
              new PolicyStatement(PolicyStatementProps
                      .builder()
                      .actions(Arrays.asList("kms:List*", "kms:Describe*", "kms:Get*", "kms:Decrypt*"))
                      .resources(singletonList("arn:aws:kms:*:*:key/*"))
                      .build()
              ),
              new PolicyStatement(PolicyStatementProps
                      .builder()
                      .actions(Arrays.asList("logs:CreateLogStream", "logs:PutLogEvents"))
                      .resources(singletonList("*"))
                      .build()
              )
      );
      final IPolicy policy = Policy.Builder.create(scope, "PoPolicy" + service.getId())
              .policyName("TaskRolePolicy-" + service.getServiceName())
              .statements(policyStatements)
              .roles(singletonList(taskRole))
              .build();

      return taskRole;
  }

  static Map<String, String> getSSMEnvironmentValues(
          final Construct construct,
          final Map<String, String> parameters,
          final String resolutionPrefix) {

    final Map<String, String> resolvedEnvironment;

    if (parameters != null && !parameters.isEmpty()) {

      resolvedEnvironment = parameters
              .entrySet()
              .stream()
              .collect(Collectors.toMap(e -> e.getKey(), e -> {

                final String value;
                if (e.getValue().startsWith(SSM_PREFIX)) {
                  final String parameterName = "/" + resolutionPrefix + e.getValue().substring(SSM_PREFIX.length());
                  value = StringParameter.valueForStringParameter(construct, parameterName);
                } else {
                  value = e.getValue();
                }

                return value;

              }));

    } else {
      resolvedEnvironment = Collections.emptyMap();
    }

    return resolvedEnvironment;

  }
}
